#!/usr/bin/env bash
# Runs in the live session right before the installer (Calamares) opens. It:
#  1. adds a first step, "Getting the latest package keys", which used to run silently
#     before the installer window appeared (the 1-3 minute "nothing happens" wait);
#  2. adds a last step that copies the CrazyOS kit into the new system, so it offers
#     the glass look and Turbo on first login;
#  3. switches the installer to the CrazyOS branding (logo, colours, slideshow).
# If anything here fails, the installer still runs exactly as CachyOS ships it.
set -u
CONF=/etc/calamares/settings.conf
KIT=/usr/share/crazyos
[[ -f "$CONF" ]] || exit 0
grep -q "shellprocess@crazyos" "$CONF" && exit 0

mkdir -p /etc/calamares/modules /etc/calamares/branding

cat > /etc/calamares/modules/shellprocess_crazyos_prep.conf <<'EOF'
---
dontChroot: true
timeout: 900
script:
  - "-timedatectl set-ntp true"
  - "-rm -rf /etc/pacman.d/gnupg"
  - "-pacman-key --init"
  - "-pacman-key --populate archlinux cachyos"
  - command: "pacman -Sy --noconfirm archlinux-keyring cachyos-keyring"
    timeout: 900
  - "-pacman-key --populate archlinux cachyos"
i18n:
  name: "Getting the latest package keys"
EOF

# CrazyOS package repository: use it when it's online (updates come through pacman)
mkdir -p /run/crazyos; rm -f /run/crazyos/repo-url /run/crazyos/packages
[[ -f "$KIT/files/repo.conf" ]] && . "$KIT/files/repo.conf"
if [[ -n "${CRAZYOS_REPO_URL:-}" ]] && curl -fsSL --max-time 20 -o /run/crazyos/crazyos.db "$CRAZYOS_REPO_URL/crazyos.db" 2>/dev/null; then
  avail="$(tar -tzf /run/crazyos/crazyos.db 2>/dev/null | sed -n 's|/$||p' | sed -E 's/-[^-]+-[^-]+$//' | sort -u)"
  if grep -qx crazyos-tools <<<"$avail"; then
    for p in crazyos-branding crazyos-themes crazyos-tools darkly kwin-effects-better-blur-dx; do
      grep -qx "$p" <<<"$avail" && echo "$p" >> /run/crazyos/packages
    done
    echo "$CRAZYOS_REPO_URL" > /run/crazyos/repo-url
    bash "$KIT/files/installer/add-repo.sh" /
    echo "CrazyOS repository online: $(tr '\n' ' ' < /run/crazyos/packages)"
  fi
fi
[[ -f /run/crazyos/repo-url ]] || echo "CrazyOS repository not reachable: CrazyOS will be copied from the USB stick"

cat > /etc/calamares/modules/shellprocess_crazyos_repo.conf <<'EOF'
---
dontChroot: true
timeout: 60
script:
  - "-bash /usr/share/crazyos/files/installer/add-repo.sh ${ROOT}"
i18n:
  name: "Adding the CrazyOS repository"
EOF

cat > /etc/calamares/modules/shellprocess_crazyos.conf <<'EOF'
---
dontChroot: true
timeout: 900
script:
  - "-bash /usr/share/crazyos/files/installer/target-setup.sh ${ROOT}"
i18n:
  name: "Making it CrazyOS"
EOF

# Branding: start from CachyOS's (so everything it references exists), then overlay CrazyOS's
if [[ -d "$KIT/files/installer/branding" ]]; then
  rm -rf /etc/calamares/branding/crazyos
  [[ -d /usr/share/calamares/branding/cachyos ]] && cp -r /usr/share/calamares/branding/cachyos /etc/calamares/branding/crazyos
  mkdir -p /etc/calamares/branding/crazyos
  cp "$KIT/files/installer/branding/"* /etc/calamares/branding/crazyos/
fi

# CrazyOS is Plasma only: no Desktop page, Plasma pre-selected, other desktops left out
CRAZYOS_PACKAGES="$(cat /run/crazyos/packages 2>/dev/null | tr '\n' ' ')" \
  python3 "$KIT/files/installer/kde-only.py" "$CONF" /etc/calamares/modules /etc/calamares/modules /usr/share/calamares/modules || true

python3 - "$CONF" <<'PY' || exit 0
import re, sys, os
p = sys.argv[1]
lines = open(p).read().split("\n")

def ind(i):
    return re.match(r"^(\s*)", lines[i]).group(1)

# last step before unmounting: copy the kit into the new system
u = next((i for i, l in enumerate(lines) if re.match(r"^\s*- umount\s*$", l)), None)
if u is None:
    sys.exit(0)
lines.insert(u, f"{ind(u)}- shellprocess@crazyos")

# right after the base system: the CrazyOS repository, so the package step can use it
pk = next((i for i, l in enumerate(lines) if re.match(r"^\s*- pacstrap\s*$", l)), None)
if pk is not None:
    lines.insert(pk + 1, f"{ind(pk)}- shellprocess@crazyos_repo")

# first step of the install: package keys (before any disk is touched)
e = next((i for i, l in enumerate(lines) if re.match(r"^- exec:\s*$", l)), None)
if e is not None and e + 1 < len(lines):
    lines.insert(e + 1, f"{ind(e + 1)}- shellprocess@crazyos_prep")

# module instances
entry = ["- id: crazyos", "  module: shellprocess", "  config: shellprocess_crazyos.conf",
         "- id: crazyos_repo", "  module: shellprocess", "  config: shellprocess_crazyos_repo.conf",
         "- id: crazyos_prep", "  module: shellprocess", "  config: shellprocess_crazyos_prep.conf"]
idx = next((i for i, l in enumerate(lines) if re.match(r"^instances:\s*$", l)), None)
if idx is not None:
    nxt = next((l for l in lines[idx + 1:] if l.strip()), "- ")
    pre = re.match(r"^(\s*)", nxt).group(1)
    lines[idx + 1:idx + 1] = [pre + x for x in entry]
else:
    seq = next(i for i, l in enumerate(lines) if re.match(r"^sequence:\s*$", l))
    lines[seq:seq] = ["instances:"] + entry + [""]

# CrazyOS branding, only if it was installed above
if os.path.exists("/etc/calamares/branding/crazyos/branding.desc"):
    lines = [re.sub(r"^branding:\s*\S+", "branding: crazyos", l) for l in lines]

open(p, "w").write("\n".join(lines))
print("CrazyOS installer steps and branding added")
PY
exit 0

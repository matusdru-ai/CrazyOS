#!/usr/bin/env python3
"""CrazyOS is KDE Plasma only. Removes the installer's "Desktop" page and makes the
package list install Plasma, without offering GNOME, Cosmic, Xfce and the rest.

usage: kde-only.py <settings.conf> <modules dir to write to> <search dir> [<search dir> ...]
The search dirs are where CachyOS's own module configs live (/etc/calamares/modules,
/usr/share/calamares/modules). Plain text editing on purpose: no YAML library needed.
"""
import os, re, sys, urllib.request

settings, out_dir, search = sys.argv[1], sys.argv[2], sys.argv[3:]
KEEP = "KDE-Desktop"


def find(name):
    for d in [out_dir] + search:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return None


# 1. which groups are desktops: the ids on CachyOS's Desktop page
pc = find("packagechooser_desktop.conf")
desktops = set()
if pc:
    desktops = {m.group(1).strip('"') for m in re.finditer(r"^\s*-\s*id:\s*(\S+)", open(pc).read(), re.M)}
desktops.discard('""'); desktops.discard("")
if not desktops:
    print("kde-only: no desktop list found, leaving the installer as is"); sys.exit(0)

# 2. the package list: CachyOS's current online list, else the copy on the USB
nc_path = find("netinstall.conf")
if not nc_path:
    print("kde-only: no netinstall.conf, leaving the installer as is"); sys.exit(0)
nc = open(nc_path).read()
urls = re.findall(r"^\s*-\s*(\S+netinstall[^\s]*\.yaml)\s*$", nc, re.M)
groups = None
for u in urls:
    try:
        if u.startswith("file://"):
            groups = open(u[7:]).read()
        else:
            groups = urllib.request.urlopen(u, timeout=15).read().decode()
        if "- name:" in groups:
            break
        groups = None
    except Exception:
        groups = None
if groups is None:
    local = find("netinstall.yaml")
    groups = open(local).read() if local else None
if groups is None:
    print("kde-only: no package list found, leaving the installer as is"); sys.exit(0)

# split into top-level groups ("- name: ..." at column 0)
blocks, cur = [], []
for line in groups.splitlines(keepends=True):
    if line.startswith("- name:") and cur:
        blocks.append(cur); cur = []
    cur.append(line)
if cur:
    blocks.append(cur)

def gname(b):
    m = re.match(r'- name:\s*"?([^"\n]+?)"?\s*$', b[0])
    return m.group(1) if m else ""

kept, dropped, found_kde = [], [], False
for b in blocks:
    n = gname(b)
    if n in desktops and n != KEEP:
        dropped.append(n); continue
    if n == KEEP:
        found_kde = True
        # the group's own flags (2-space indent): installed, and not shown as a choice
        for flag, val in (("selected", "true"), ("hidden", "true")):
            for i, l in enumerate(b):
                if re.match(rf"^  {flag}:\s*\S+\s*$", l):
                    b[i] = f"  {flag}: {val}\n"; break
    kept.append(b)
if not found_kde:
    print("kde-only: Plasma group not in the package list, leaving the installer as is"); sys.exit(0)

# CrazyOS's own packages, from the [crazyos] repository (only when it's online)
extra = os.environ.get("CRAZYOS_PACKAGES", "").split()
if extra:
    kept.insert(0, ['- name: "CrazyOS"\n',
                    '  description: "CrazyOS look, Welcome, Turbo and the glass blur"\n',
                    '  hidden: true\n', '  selected: true\n', '  critical: true\n',
                    '  packages:\n'] + [f"    - {p}\n" for p in extra])

os.makedirs(out_dir, exist_ok=True)
yaml_out = os.path.join(out_dir, "netinstall-crazyos.yaml")
open(yaml_out, "w").write("".join("".join(b) for b in kept))

# 3. package page reads only the CrazyOS list
lines, skip = [], False
for l in nc.splitlines():
    if re.match(r"^groupsUrl\s*:", l):
        lines += ["groupsUrl:", f" - file://{yaml_out}"]; skip = True; continue
    if skip and re.match(r"^\s+-\s", l):
        continue
    skip = False
    lines.append(l)
open(os.path.join(out_dir, "netinstall.conf"), "w").write("\n".join(lines) + "\n")

# 4. no Desktop page
s = open(settings).read()
s2 = re.sub(r"^\s*-\s*packagechooser@desktop\s*\n", "", s, flags=re.M)
open(settings, "w").write(s2)

print(f"kde-only: CrazyOS packages: {' '.join(extra) or 'none (repository offline)'}; Plasma pre-selected; removed {', '.join(dropped) or 'nothing'}; Desktop page {'removed' if s2 != s else 'not found'}")

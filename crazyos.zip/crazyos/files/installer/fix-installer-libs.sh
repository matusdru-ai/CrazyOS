#!/bin/bash
# Supplies Boost libraries the installer was built against when Arch has already moved
# to a newer Boost (CachyOS rebuilds Calamares a little later). Only the exact missing
# .so files are added from the Arch archive; the current Boost stays installed.
#   fix-installer-libs.sh <target-root> <soname> [<soname>...]
#   e.g. fix-installer-libs.sh / libboost_python314.so.1.91.0
set -u
root="${1:?target root}"; shift
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
rc=0
for so in "$@"; do
  [[ -e "$root/usr/lib/$so" ]] && continue
  ver="${so##*.so.}"                                   # 1.91.0
  [[ "$so" == libboost_* && "$ver" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "  can't supply $so"; rc=1; continue; }
  pkg="$(ls -1 "$tmp"/boost-libs-"$ver"-*.pkg.tar.zst 2>/dev/null | head -n1)"   # already downloaded for an earlier lib
  [[ -n "$pkg" ]] || for rel in 6 5 4 3 2 1; do                          # newest release first
    f="boost-libs-$ver-$rel-x86_64.pkg.tar.zst"
    if curl -fsSL --max-time 180 -o "$tmp/$f" "https://archive.archlinux.org/packages/b/boost-libs/$f" 2>/dev/null; then
      pkg="$tmp/$f"; break
    fi
    rm -f "$tmp/$f"
  done
  if [[ -z "$pkg" ]]; then echo "  couldn't download Boost $ver"; rc=1; continue; fi
  if bsdtar -xpf "$pkg" -C "$root" "usr/lib/libboost_*.so.$ver" 2>/dev/null && [[ -e "$root/usr/lib/$so" ]]; then
    echo "  added $so (from $(basename "$pkg"))"
  else
    echo "  $so not in $(basename "$pkg")"; rc=1
  fi
done
exit $rc

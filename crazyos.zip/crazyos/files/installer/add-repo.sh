#!/bin/bash
# Adds the [crazyos] package repository to a pacman.conf (only if the live session found
# it online). [crazyos] goes first, so its builds of Darkly and Better Blur DX are used.
#   add-repo.sh <root>      (root "/" = the live session itself)
R="${1:-/}"; CONF="${R%/}/etc/pacman.conf"
[[ -f /run/crazyos/repo-url && -f "$CONF" ]] || exit 0
grep -q '^\[crazyos\]' "$CONF" && exit 0
URL="$(cat /run/crazyos/repo-url)"
python3 - "$CONF" "$URL" <<'PY'
import re, sys
p, url = sys.argv[1], sys.argv[2]
s = open(p).read()
block = f"[crazyos]\n# CrazyOS packages (look, Welcome, Turbo, Darkly, Better Blur DX)\nSigLevel = Optional TrustAll\nServer = {url}\n\n"
m = re.search(r"^\[(?!options\])[^\]]+\]", s, re.M)
s = s[:m.start()] + block + s[m.start():] if m else s.rstrip() + "\n\n" + block
open(p, "w").write(s)
PY
echo "CrazyOS repository added to $CONF"

#!/bin/bash
# Last installer step: turns the freshly installed system into CrazyOS.
#   target-setup.sh <root of the new system>
# Works with the CrazyOS packages (installed from the [crazyos] repository) and, if that
# repository wasn't reachable, falls back to copying everything from the USB stick.
set -u
R="${1:?root}"; KIT=/usr/share/crazyos
log() { echo "crazyos: $*"; }

bash "$KIT/files/installer/add-repo.sh" "$R"

if compgen -G "$R/var/lib/pacman/local/crazyos-tools-*" >/dev/null; then
  log "CrazyOS packages installed from the repository"
else
  log "repository not used: copying CrazyOS from the USB stick"
  mkdir -p "$R/usr/share" "$R/usr/local/bin" "$R/etc/xdg/autostart" "$R/usr/share/applications"
  cp -r "$KIT" "$R/usr/share/"
  for t in crazyos-glass crazyos-turbo crazyos-welcome; do install -m755 "/usr/local/bin/$t" "$R/usr/local/bin/$t"; done
  install -m644 "$KIT/files/welcome/crazyos-welcome.desktop" "$R/usr/share/applications/"
  install -m644 "$KIT/files/welcome/crazyos-welcome.desktop" "$R/etc/xdg/autostart/"
  install -m644 "$KIT/files/crazyos-firstlogin.desktop" "$R/etc/xdg/autostart/"
  # themes, wallpaper, colours, logo system-wide (same layout as the packages)
  [[ -d "$KIT/themes/local-share" ]] && cp -r "$KIT/themes/local-share/." "$R/usr/share/"
  [[ -d "$KIT/themes/kvantum" ]] && { mkdir -p "$R/usr/share/Kvantum"; cp -r "$KIT/themes/kvantum/." "$R/usr/share/Kvantum/"; }
  [[ -d "$KIT/themes/gtk/WhiteSur-Dark" ]] && { mkdir -p "$R/usr/share/themes"; cp -r "$KIT/themes/gtk/WhiteSur-Dark" "$R/usr/share/themes/"; }
  bash "$KIT/files/brand-themes.sh" "$R/usr/share" "$KIT/files/branding"
  mkdir -p "$R/usr/share/wallpapers/CrazyOS/contents/images" "$R/usr/share/color-schemes"
  cp "$KIT/files/wallpaper/3840x2160.png" "$R/usr/share/wallpapers/CrazyOS/contents/images/"
  printf '{"KPlugin":{"Id":"CrazyOS","Name":"CrazyOS","Authors":[{"Name":"CrazyOS"}],"License":"CC-BY-SA-4.0"}}\n' > "$R/usr/share/wallpapers/CrazyOS/metadata.json"
  cp "$KIT/files/colors/CrazyOS.colors" "$R/usr/share/color-schemes/"
  # keep the name on updates
  install -Dm755 "$KIT/files/os-release.sh" "$R/usr/share/libalpm/scripts/crazyos-os-release"
  install -Dm644 "$KIT/files/crazyos-os-release.hook" "$R/usr/share/libalpm/hooks/90-crazyos-os-release.hook"
fi

# Name: CrazyOS everywhere (os-release, GRUB title)
bash "$KIT/files/os-release.sh" "$R"

# No CachyOS Hello at login; CrazyOS Welcome instead (also after Hello updates)
rm -f "$R/etc/xdg/autostart/cachyos-hello.desktop" "$R/etc/skel/.config/autostart/cachyos-hello.desktop" \
      "$R"/home/*/.config/autostart/cachyos-hello.desktop "$R/etc/xdg/autostart/crazyos-firstrun.desktop"
grep -q 'cachyos-hello.desktop' "$R/etc/pacman.conf" 2>/dev/null || \
  sed -i '/^\[options\]/a NoExtract = etc/xdg/autostart/cachyos-hello.desktop' "$R/etc/pacman.conf"

# The look from the very first login: default settings for new users + the user just created
DARKLY=0; compgen -G "$R/usr/lib/qt6/plugins/styles/darkly6*.so" >/dev/null && DARKLY=1
if python3 "$KIT/files/preseed.py" "$R" "$KIT" "$R" "$DARKLY" >/dev/null; then
  for h in "$R"/home/*/; do
    [[ -d "$h" ]] || continue
    (cd "$R/etc/skel" && find .config .local -type f 2>/dev/null) | while IFS= read -r f; do
      case "$f" in .config/autostart/*) continue ;; esac
      mkdir -p "$h$(dirname "$f")"; cp "$R/etc/skel/$f" "$h$f"
    done
    chown -R --reference="$h" "$h.config" "$h.local" 2>/dev/null
  done
  log "glass look set for the first login"
fi
exit 0

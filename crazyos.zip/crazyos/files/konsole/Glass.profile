[Appearance]
ColorScheme=Glass
Font=JetBrainsMono Nerd Font,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1
UseFontLineChararacters=true

[General]
Name=Glass
Parent=FALLBACK/
TerminalCenter=true
TerminalMargin=14

[Scrolling]
ScrollBarPosition=2

#!/bin/bash
# Makes the system call itself CrazyOS (login screen, "About this system", fastfetch,
# boot menu titles). Run by a pacman hook whenever the base os-release changes.
#   os-release.sh [<root>]
R="${1:-}"
src="$R/usr/lib/os-release"
[[ -f "$src" ]] || exit 0
tmp="$(mktemp)"
grep -vE '^(NAME|PRETTY_NAME|LOGO|HOME_URL|DOCUMENTATION_URL|SUPPORT_URL|BUG_REPORT_URL|ANSI_COLOR|VARIANT|VARIANT_ID)=' "$src" > "$tmp"
cat >> "$tmp" <<'O'
NAME="CrazyOS"
PRETTY_NAME="CrazyOS"
VARIANT="based on CachyOS"
VARIANT_ID=crazyos
LOGO=crazyos
ANSI_COLOR="38;2;124;245;208"
HOME_URL="https://crazyaimone.netlify.app/crazyos/"
DOCUMENTATION_URL="https://crazyaimone.netlify.app/crazyos/"
SUPPORT_URL="https://github.com/matusdru-ai/CrazyOS-glass-/issues"
BUG_REPORT_URL="https://github.com/matusdru-ai/CrazyOS-glass-/issues"
O
rm -f "$R/etc/os-release"            # usually a symlink to /usr/lib/os-release
install -m644 "$tmp" "$R/etc/os-release"; rm -f "$tmp"
echo "CrazyOS" > "$R/etc/crazyos-release"
# GRUB menu title (systemd-boot and Limine take it from os-release)
[[ -f "$R/etc/default/grub" ]] && sed -i -E 's/^GRUB_DISTRIBUTOR=.*/GRUB_DISTRIBUTOR="CrazyOS"/' "$R/etc/default/grub"
exit 0

#!/usr/bin/env python3
"""Bake the CrazyOS look into the live image's default user settings (/etc/skel), so the
live session starts glass from the very first frame instead of switching after login.
The runtime setup (glass-setup.sh --live) still runs afterwards for the panel layout,
top bar and blur extras.

usage: preseed.py <airootfs root> <kit dir> <cachyos-kde-settings checkout> <darkly:0|1>
"""
import os, re, shutil, sys

ROOT, KIT, CKS, DARKLY = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] == "1"
SKEL = os.path.join(ROOT, "etc/skel")
CFG = os.path.join(SKEL, ".config")
WALL = "/usr/share/wallpapers/CrazyOS/contents/images/3840x2160.png"


class Ini:
    """Minimal KDE-style ini editor that keeps everything it doesn't touch."""
    def __init__(self, path):
        self.path, self.groups = path, []          # [(header, [lines])]
        cur = ("", [])
        self.groups.append(cur)
        if os.path.exists(path):
            for line in open(path, encoding="utf-8", errors="replace").read().splitlines():
                if line.startswith("[") and line.rstrip().endswith("]"):
                    cur = (line.strip(), []); self.groups.append(cur)
                else:
                    cur[1].append(line)

    def set(self, group, key, value):
        header = "".join(f"[{g}]" for g in (group if isinstance(group, (list, tuple)) else [group]))
        for h, lines in self.groups:
            if h == header:
                for i, l in enumerate(lines):
                    if l.split("=", 1)[0].strip() == key and "=" in l:
                        lines[i] = f"{key}={value}"; return
                while lines and not lines[-1].strip():
                    lines.pop()
                lines.append(f"{key}={value}"); lines.append("")
                return
        self.groups.append((header, [f"{key}={value}", ""]))

    def merge_file(self, other, only=None):
        for h, lines in Ini(other).groups:
            if not h or (only and not re.match(only, h)):
                continue
            g = re.findall(r"\[([^\]]*)\]", h)
            for l in lines:
                if "=" in l and not l.lstrip().startswith("#"):
                    k, v = l.split("=", 1); self.set(g, k.strip(), v)

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        out = []
        for h, lines in self.groups:
            if h:
                if out and out[-1].strip():
                    out.append("")
                out.append(h)
            out.extend(lines)
        open(self.path, "w", encoding="utf-8").write("\n".join(out).rstrip() + "\n")


def start_from_cachyos(rel):
    """Start from CachyOS's own default so nothing it sets is lost."""
    dst = os.path.join(CFG, rel)
    src = os.path.join(CKS, "etc/skel/.config", rel)
    if os.path.exists(src) and not os.path.exists(dst):
        os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy(src, dst)
    return Ini(dst)


F = "Inter,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1"
scheme = "CrazyOS" if DARKLY else "WhiteSurLiquidDark"
for rel in ("kdeglobals", "kdedefaults/kdeglobals"):
    k = start_from_cachyos(rel)
    colors = os.path.join(KIT, "files/colors/CrazyOS.colors") if DARKLY else \
        os.path.join(ROOT, "usr/share/color-schemes/WhiteSurLiquidDark.colors")
    if os.path.exists(colors):
        k.merge_file(colors, only=r"^\[(Colors:|ColorEffects:|WM\])")
    k.set("General", "ColorScheme", scheme)
    k.set("Icons", "Theme", "WhiteSur-dark")
    k.set("KDE", "widgetStyle", "Darkly" if DARKLY else "kvantum")
    k.set("KDE", "LookAndFeelPackage", "com.github.vinceliuice.WhiteSurLiquid-dark")
    k.set("KDE", "AnimationDurationFactor", "0.7071067811865475")
    for key in ("font", "menuFont", "toolBarFont"):
        k.set("General", key, F)
    k.set("General", "fixed", "JetBrainsMono Nerd Font,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1")
    k.set("General", "XftHintStyle", "hintslight")
    k.set("WM", "activeFont", "Inter,10,-1,5,600,0,0,0,0,0,0,0,0,0,0,1")
    k.save()

p = Ini(os.path.join(CFG, "plasmarc")); p.set("Theme", "name", "WhiteSurLiquid-dark"); p.save()

for rel in ("kwinrc", "kdedefaults/kwinrc"):
    w = start_from_cachyos(rel)
    w.set("org.kde.kdecoration2", "library", "org.kde.kwin.aurorae")
    w.set("org.kde.kdecoration2", "theme", "__aurorae__svg__WhiteSurLiquid-dark")
    w.set("org.kde.kdecoration2", "ButtonsOnLeft", "XIA")
    w.set("org.kde.kdecoration2", "ButtonsOnRight", "")
    w.set("Plugins", "contrastEnabled", "true")
    w.set("Plugins", "wobblywindowsEnabled", "false")
    w.save()

c = start_from_cachyos("kcminputrc"); c.set("Mouse", "cursorTheme", "WhiteSur-cursors"); c.save()

if DARKLY:
    d = Ini(os.path.join(CFG, "darklyrc"))
    d.set("Common", "CornerRadius", "10")
    for key, val in (("MenuOpacity", 70), ("MenuBarOpacity", 40), ("ToolBarOpacity", 40), ("TabBarOpacity", 50),
                     ("DolphinSidebarOpacity", 45), ("DolphinViewOpacity", 0), ("NewDolphinSelectionStyle", "true"),
                     ("AdjustToDarkThemes", "true"), ("ViewDrawFocusIndicator", "false"), ("TabBarDrawCenteredTabs", "true")):
        d.set("Style", key, val)
    d.save()
else:
    kv = Ini(os.path.join(CFG, "Kvantum/kvantum.kvconfig")); kv.set("General", "theme", "WhiteSurLiquidDark"); kv.save()

for v in ("3.0", "4.0"):
    g = start_from_cachyos(f"gtk-{v}/settings.ini")
    for key, val in (("gtk-theme-name", "WhiteSur-Dark"), ("gtk-icon-theme-name", "WhiteSur-dark"),
                     ("gtk-cursor-theme-name", "WhiteSur-cursors"), ("gtk-font-name", "Inter 10"),
                     ("gtk-application-prefer-dark-theme", "true"),
                     ("gtk-decoration-layout", "close,minimize,maximize:")):
        g.set("Settings", key, val)
    g.save()

# Wallpaper on the desktop and the lock screen
a = start_from_cachyos("plasma-org.kde.plasma.desktop-appletsrc")
for h, lines in a.groups:
    if h.endswith("[Wallpaper][org.kde.image][General]"):
        for i, l in enumerate(lines):
            if l.startswith(("Image=", "PreviewImage=")):
                lines[i] = l.split("=", 1)[0] + "=file://" + WALL
a.save()
s = Ini(os.path.join(CFG, "kscreenlockerrc"))
s.set(["Greeter", "Wallpaper", "org.kde.image", "General"], "Image", "file://" + WALL)
s.set(["Greeter", "Wallpaper", "org.kde.image", "General"], "PreviewImage", "file://" + WALL)
s.save()

# Konsole glass profile as default
src = os.path.join(KIT, "files/konsole")
if os.path.isdir(src):
    dst = os.path.join(SKEL, ".local/share/konsole"); os.makedirs(dst, exist_ok=True)
    for f in os.listdir(src):
        shutil.copy(os.path.join(src, f), dst)
    kr = Ini(os.path.join(CFG, "konsolerc")); kr.set("Desktop Entry", "DefaultProfile", "Glass.profile"); kr.save()

print("pre-seeded:", ", ".join(sorted(os.listdir(CFG))))

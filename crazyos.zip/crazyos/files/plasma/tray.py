#!/usr/bin/env python3
"""CrazyOS clean top bar: only Wi-Fi/network and sound stay visible in the system tray.
Everything else (Bluetooth, brightness, night light, displays, devices, clipboard, media,
notifications…) moves into the tray's single popup panel, opened with one click.
Edits ~/.config/plasma-org.kde.plasma.desktop-appletsrc while plasmashell is stopped."""
import os, re, sys

path = os.path.expanduser("~/.config/plasma-org.kde.plasma.desktop-appletsrc")
if not os.path.exists(path):
    sys.exit(0)

SHOWN = ["org.kde.plasma.networkmanagement", "org.kde.plasma.volume"]
HIDDEN = [
    "org.kde.plasma.bluetooth", "org.kde.plasma.brightness", "org.kde.plasma.nightcolorcontrol",
    "org.kde.plasma.nightlight", "org.kde.kscreen", "org.kde.plasma.devicenotifier",
    "org.kde.plasma.clipboard", "org.kde.plasma.mediacontroller", "org.kde.plasma.notifications",
    "org.kde.plasma.keyboardindicator", "org.kde.plasma.keyboardlayout", "org.kde.plasma.manage-inputmethod",
    "org.kde.plasma.printmanager", "org.kde.kdeconnect", "org.kde.plasma.vault", "org.kde.plasma.cameraindicator",
    "org.kde.plasma.weather", "org.kde.plasma.battery",
]

text = open(path, encoding="utf-8").read()
lines = text.split("\n")

# containment ids whose plugin is the system tray
ids, cur = [], None
for l in lines:
    m = re.match(r"^\[Containments\]\[(\d+)\]$", l)
    if m:
        cur = m.group(1); continue
    if l.startswith("["):
        cur = None; continue
    if cur and l.strip() == "plugin=org.kde.plasma.private.systemtray":
        ids.append(cur)
if not ids:
    sys.exit(0)

def set_keys(lines, group, kv):
    hdr = f"[Containments][{group}][General]"
    if hdr not in lines:
        lines += ["", hdr] + [f"{k}={v}" for k, v in kv.items()]
        return lines
    i = lines.index(hdr) + 1
    j = i
    while j < len(lines) and not lines[j].startswith("["):
        j += 1
    body = [l for l in lines[i:j] if l.split("=", 1)[0] not in kv]
    while body and body[-1] == "":
        body.pop()
    body += [f"{k}={v}" for k, v in kv.items()] + [""]
    return lines[:i] + body + lines[j:]

for cid in ids:
    lines = set_keys(lines, cid, {
        "shownItems": ",".join(SHOWN),
        "hiddenItems": ",".join(HIDDEN),
        "scaleIconsToFit": "false",
        "iconSpacing": "2",
    })

open(path, "w", encoding="utf-8").write("\n".join(lines))
print(f"tray cleaned in {len(ids)} system tray(s)")

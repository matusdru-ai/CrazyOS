// CrazyOS Welcome. Replaces CachyOS Hello.
// Started by /usr/local/bin/crazyos-welcome, which passes the state as arguments
// (mode=live|installed, glass=0|1, turbo=0|1, autostart=0|1) and runs the actions this
// window asks for: it prints "ACTION:<name>" and the launcher does the work.
import QtQuick
import QtQuick.Window
import QtQuick.Layouts

Window {
    id: win
    width: 900; height: live ? 560 : 640
    minimumWidth: 720; minimumHeight: 520
    visible: true
    title: "Welcome to CrazyOS"
    color: "#141828"

    function arg(name, def) {
        var a = Qt.application.arguments
        for (var i = 0; i < a.length; i++)
            if (a[i].indexOf(name + "=") === 0) return a[i].substring(name.length + 1)
        return def
    }
    readonly property bool live: arg("mode", "installed") === "live"
    property bool glassDone: arg("glass", "0") === "1"
    property bool turboDone: arg("turbo", "0") === "1"
    property bool autostart: arg("autostart", "1") === "1"
    readonly property string kit: arg("kit", "/usr/share/crazyos")

    readonly property color mint: "#7CF5D0"
    readonly property color ink: "#F4F6FF"
    readonly property color dim: "#A9B0CC"
    readonly property string uiFont: "Inter"

    function act(name) { console.log("ACTION:" + name) }

    // ---------- background: the CrazyOS splash, darkened ----------
    Image {
        anchors.fill: parent
        source: "file://" + win.kit + "/files/branding/splash.png"
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        opacity: 0.85
    }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#7a0b0e1c" }
            GradientStop { position: 1.0; color: "#e60b0e1c" }
        }
    }

    // ---------- reusable pieces ----------
    component GlassButton: Rectangle {
        id: btn
        property string text: ""
        property bool primary: false
        signal clicked()
        implicitWidth: label.implicitWidth + 44
        implicitHeight: 48
        radius: 24
        color: primary ? (hover.containsMouse ? "#9BFFE0" : win.mint)
                       : (hover.containsMouse ? "#33ffffff" : "#1fffffff")
        border.width: primary ? 0 : 1
        border.color: "#40ffffff"
        Behavior on color { ColorAnimation { duration: 120 } }
        Text {
            id: label
            anchors.centerIn: parent
            text: btn.text
            color: btn.primary ? "#0b1222" : win.ink
            font.family: win.uiFont; font.pixelSize: 16; font.weight: Font.DemiBold
        }
        MouseArea {
            id: hover
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: btn.clicked()
        }
    }

    component Card: Rectangle {
        id: card
        property string icon: ""
        property string title: ""
        property string body: ""
        property string badge: ""
        property bool highlight: false
        signal clicked()
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.minimumHeight: 118
        radius: 20
        color: ma.containsMouse ? "#2affffff" : "#16ffffff"
        border.width: 1
        border.color: highlight ? "#807CF5D0" : "#30ffffff"
        Behavior on color { ColorAnimation { duration: 120 } }
        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 6
            RowLayout {
                spacing: 10
                Text { text: card.icon; font.pixelSize: 22 }
                Text {
                    text: card.title
                    color: win.ink
                    font.family: win.uiFont; font.pixelSize: 17; font.weight: Font.DemiBold
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
                Rectangle {
                    visible: card.badge !== ""
                    radius: 10; height: 22
                    width: badgeText.implicitWidth + 16
                    color: "#287CF5D0"
                    border.width: 1; border.color: "#597CF5D0"
                    Text {
                        id: badgeText
                        anchors.centerIn: parent
                        text: card.badge
                        color: win.mint
                        font.family: win.uiFont; font.pixelSize: 11; font.weight: Font.Bold
                    }
                }
            }
            Text {
                text: card.body
                color: win.dim
                font.family: win.uiFont; font.pixelSize: 13.5
                wrapMode: Text.WordWrap
                lineHeight: 1.15
                Layout.fillWidth: true
            }
            Item { Layout.fillHeight: true }
        }
        MouseArea {
            id: ma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: card.clicked()
        }
    }

    // ---------- content ----------
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 36
        spacing: 18

        RowLayout {
            spacing: 16
            Image {
                source: "file://" + win.kit + "/files/branding/crazyos.svg"
                sourceSize.width: 56; sourceSize.height: 56
                Layout.preferredWidth: 56; Layout.preferredHeight: 56
            }
            ColumnLayout {
                spacing: 2
                Text {
                    text: "Welcome to CrazyOS"
                    color: win.ink
                    font.family: win.uiFont; font.pixelSize: 32; font.weight: Font.Bold
                }
                Text {
                    text: "Liquid glass. Built for speed."
                    color: win.mint
                    font.family: win.uiFont; font.pixelSize: 16; font.weight: Font.DemiBold
                }
            }
        }

        // ===== live USB =====
        ColumnLayout {
            visible: win.live
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 18
            Text {
                text: "You're running CrazyOS from the USB stick. Nothing on this PC has changed yet.\nTry it out as long as you like, then install it when you're ready. It takes about 5 to 15 minutes."
                color: win.dim
                font.family: win.uiFont; font.pixelSize: 15
                wrapMode: Text.WordWrap
                lineHeight: 1.2
                Layout.fillWidth: true
            }
            RowLayout {
                spacing: 12
                GlassButton { text: "Install CrazyOS"; primary: true; onClicked: { win.act("install"); Qt.quit() } }
                GlassButton { text: "Try it first"; onClicked: Qt.quit() }
            }
            GridLayout {
                columns: 3
                rowSpacing: 12; columnSpacing: 12
                Layout.fillWidth: true
                Layout.fillHeight: true
                Card { icon: "📶"; title: "Wi-Fi"; body: "Connect to the internet first. The installer downloads the newest packages."; onClicked: win.act("network") }
                Card { icon: "🖥️"; title: "Displays"; body: "Set resolution, refresh rate and scaling for your monitor."; onClicked: win.act("display") }
                Card { icon: "🌐"; title: "Website"; body: "What CrazyOS does, explained."; onClicked: win.act("website") }
            }
        }

        // ===== installed =====
        GridLayout {
            visible: !win.live
            columns: 3
            rowSpacing: 12; columnSpacing: 12
            Layout.fillWidth: true
            Layout.fillHeight: true
            Card {
                icon: "💎"; title: "Glass look"
                badge: win.glassDone ? "ON" : ""
                highlight: !win.glassDone
                body: win.glassDone ? "Applied. Click to re-apply it, e.g. after a big Plasma update."
                                    : "Start here: frosted panels, glass windows, the CrazyOS dock and wallpaper."
                onClicked: win.act("glass")
            }
            Card {
                icon: "⚡"; title: "Turbo"
                badge: win.turboDone ? "ON" : ""
                highlight: win.glassDone && !win.turboDone
                body: win.turboDone ? "Gaming tuning is on. Click to check it or change options."
                                    : "Low input lag, fast networking, NVIDIA and CPU tuning for games."
                onClicked: win.act("turbo")
            }
            Card { icon: "🎮"; title: "Gaming apps"; body: "Steam, Lutris, Heroic, Proton and the tools games need."; onClicked: win.act("gaming") }
            Card { icon: "⬆️"; title: "Update"; body: "Get the latest kernel, drivers and apps."; onClicked: win.act("update") }
            Card { icon: "⏱️"; title: "Boot speed"; body: "See how fast this PC starts and what slows it down."; onClicked: win.act("bootreport") }
            Card { icon: "⚙️"; title: "Settings"; body: "Displays, sound, mouse, keyboard and everything else."; onClicked: win.act("settings") }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            Rectangle {
                id: box
                visible: !win.live
                width: 22; height: 22; radius: 6
                color: win.autostart ? win.mint : "transparent"
                border.width: 1.5; border.color: win.autostart ? win.mint : "#80ffffff"
                Text { anchors.centerIn: parent; text: "✓"; visible: win.autostart; color: "#0b1222"; font.pixelSize: 14; font.bold: true }
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: { win.autostart = !win.autostart; win.act(win.autostart ? "autostart-on" : "autostart-off") }
                }
            }
            Text {
                visible: !win.live
                text: "Show this when I log in"
                color: win.dim
                font.family: win.uiFont; font.pixelSize: 13.5
                MouseArea { anchors.fill: parent; onClicked: { win.autostart = !win.autostart; win.act(win.autostart ? "autostart-on" : "autostart-off") } }
            }
            Item { Layout.fillWidth: true }
            Text {
                text: "Open again any time: search “Welcome” in the menu"
                color: "#7d84a3"
                font.family: win.uiFont; font.pixelSize: 12.5
            }
        }
    }
}

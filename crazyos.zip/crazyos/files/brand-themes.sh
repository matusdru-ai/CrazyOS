#!/bin/bash
# Puts the CrazyOS logo into the WhiteSur themes (menu button, icons, loading screen)
# instead of the Apple logo they ship with.
#   brand-themes.sh <share dir> [<branding dir>]
#   e.g. brand-themes.sh ~/.local/share        (one user)
#        brand-themes.sh "$pkgdir/usr/share"   (system-wide, when packaging)
SHARE="${1:?share dir}"
B="${2:-$(cd "$(dirname "$(readlink -f "$0")")" && pwd)/branding}"
[[ -f "$B/crazyos.svg" ]] || { echo "brand-themes: no logo in $B" >&2; exit 1; }

for d in "$SHARE"/icons/WhiteSur*/; do
  [[ -d "$d" && "$d" != *cursors* ]] || continue
  while IFS= read -r f; do
    rm -f "$f"     # also breaks hard links / symlinks, so only this copy changes
    case "$f" in *symbolic*) cp "$B/crazyos-symbolic.svg" "$f" ;; *) cp "$B/crazyos.svg" "$f" ;; esac
  done < <(find "$d" -name 'start-here*.svg')
  for sub in places/scalable apps/scalable; do
    [[ -d "$d$sub" ]] || continue
    for n in start-here-cachyos start-here-kde start-here-archlinux crazyos; do
      rm -f "$d$sub/$n.svg"; cp "$B/crazyos.svg" "$d$sub/$n.svg"
    done
  done
  rm -f "$d/icon-theme.cache"
  command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -f -q -t "$d" 2>/dev/null
done

mkdir -p "$SHARE/icons/hicolor/scalable/apps"
for f in crazyos.svg crazyos-symbolic.svg; do rm -f "$SHARE/icons/hicolor/scalable/apps/$f"; cp "$B/$f" "$SHARE/icons/hicolor/scalable/apps/"; done

for sp in "$SHARE"/plasma/look-and-feel/com.github.vinceliuice.WhiteSur*/contents/splash; do
  [[ -f "$sp/Splash.qml" ]] || continue
  rm -f "$sp/images/logo.png"; cp "$B/splash-logo.png" "$sp/images/logo.png"
  grep -q 'images/logo.png' "$sp/Splash.qml" || \
    sed -i 's|source: "images/logo.svg"|source: "images/logo.png"; width: 420; height: 111; fillMode: Image.PreserveAspectFit; smooth: true|' "$sp/Splash.qml"
done
exit 0

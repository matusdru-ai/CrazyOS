#!/usr/bin/env bash
# CrazyOS Turbo — gaming / low-latency tuning on top of CachyOS's own defaults.
# Built for: Ryzen 7 9800X3D · RTX 5080 · Samsung NVMe · 2.5 GbE. Works on similar AMD + NVIDIA desktops.
#
#   ./turbo-setup.sh            check the hardware, then apply
#   ./turbo-setup.sh --check    only check, change nothing
#   ./turbo-setup.sh --scx      also switch the CPU scheduler to scx_lavd (gaming mode)
#   ./turbo-setup.sh --always-performance   keep the CPU in performance mode all the time
#   ./turbo-setup.sh --autologin   log straight into the desktop at boot (no password screen)
#   ./turbo-setup.sh --boot-report show how long the last boot took, part by part
#
# Everything goes into separate new files (listed at the end). Undo: ./turbo-restore.sh
set -uo pipefail

R="${TURBO_ROOT:-}"            # test prefix; empty on a real system
KIT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
CHECK=0 SCX=0 ALWAYS=0 AUTOLOGIN=0 BOOTREPORT=0
for a in "$@"; do
  case "$a" in
    --check) CHECK=1 ;;
    --scx) SCX=1 ;;
    --always-performance) ALWAYS=1 ;;
    --autologin) AUTOLOGIN=1 ;;
    --boot-report) BOOTREPORT=1 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "Unknown option: $a"; exit 1 ;;
  esac
done

c_b=$'\e[1m' c_c=$'\e[38;5;117m' c_g=$'\e[38;5;79m' c_y=$'\e[38;5;221m' c_r=$'\e[38;5;203m' c_d=$'\e[2m' c_0=$'\e[0m'
step() { printf '\n%s◆ %s%s\n' "$c_c$c_b" "$*" "$c_0"; }
ok()   { printf '  %s✓%s %s\n' "$c_g" "$c_0" "$*"; }
warn() { printf '  %s!%s %s\n' "$c_y" "$c_0" "$*"; WARNS=$((WARNS+1)); }
info() { printf '  %s·%s %s\n' "$c_d" "$c_0" "$*"; }
die()  { printf '%s✗ %s%s\n' "$c_r" "$*" "$c_0"; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }
put()  { local f="$R$1"; sudo mkdir -p "$(dirname "$f")"; sudo tee "$f" >/dev/null; echo "$1" >> "$MANIFEST.tmp"; }
WARNS=0

[[ $EUID -eq 0 && -z "$R" ]] && die "Run as your normal user (it uses sudo when needed)."

boot_report() {
  have systemd-analyze || return 0
  local line fw ld kn ird us tot
  line="$(systemd-analyze 2>/dev/null | head -1)"
  [[ -n "$line" ]] || return 0
  sec() { echo "$line" | grep -oE "[0-9.]+(min|s|ms) \($1\)" | head -1 | awk '{v=$1; if (v ~ /min$/) {sub(/min/,"",v); v*=60} else if (v ~ /ms$/) {sub(/ms/,"",v); v/=1000} else sub(/s$/,"",v); printf "%.1f", v}'; }
  fw=$(sec firmware); ld=$(sec loader); kn=$(sec kernel); ird=$(sec initrd); us=$(sec userspace)
  tot=$(awk -v a="${fw:-0}" -v b="${ld:-0}" -v c="${kn:-0}" -v d="${ird:-0}" -v e="${us:-0}" 'BEGIN{printf "%.1f", a+b+c+d+e}')
  info "Last boot: ${tot}s to the login screen (BIOS ${fw:-?}s, boot menu ${ld:-?}s, kernel ${kn:-?}s, initrd ${ird:-?}s, system ${us:-?}s)"
  if awk -v f="${fw:-0}" 'BEGIN{exit !(f>10)}'; then
    warn "The BIOS takes ${fw}s. Turn on 'Memory Context Restore' and 'Power Down Enable' in the BIOS memory settings; on AM5 this often halves it."
  fi
  if awk -v l="${ld:-0}" 'BEGIN{exit !(l>2)}'; then info "The boot menu waits ${ld}s; Turbo sets it to 1s."; fi
  if [[ $BOOTREPORT == 1 ]]; then
    printf '\n  Slowest services this boot:\n'
    systemd-analyze blame 2>/dev/null | head -8 | sed 's/^/    /'
    [[ -f "$HOME/.local/share/crazyos/boot-before.txt" ]] && printf '\n  Before Turbo: %s\n' "$(cat "$HOME/.local/share/crazyos/boot-before.txt")"
  fi
  return 0
}
have pacman || die "This is meant for CachyOS."

printf '\n%s  ⚡ CrazyOS Turbo%s\n' "$c_c$c_b" "$c_0"
if [[ $BOOTREPORT == 1 ]]; then step "Boot time"; boot_report; echo; exit 0; fi

# ======================================================================= CHECK
step "Checking your hardware and setup"
CPU=$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2- | sed 's/^ *//')
info "CPU: ${CPU:-unknown}"
DRV=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_driver 2>/dev/null)
[[ "$DRV" == amd-pstate-epp ]] && ok "CPU driver amd-pstate (active mode)" || warn "CPU driver is '${DRV:-?}', expected amd-pstate-epp"
uname -r | grep -q cachyos && ok "Kernel $(uname -r)" || warn "Not on a CachyOS kernel ($(uname -r)). Install linux-cachyos."
if grep -Eq '^\[cachyos-(znver4|v4)\]' /etc/pacman.conf 2>/dev/null; then
  ok "Packages built for your CPU ($(grep -Eo '^\[cachyos-(znver4|v4)\]' /etc/pacman.conf | head -1))"
else
  warn "Not using the Zen 4/5-optimised CachyOS repo. A fresh CachyOS install sets this up automatically."
fi

if have nvidia-smi; then
  GPU=$(nvidia-smi --query-gpu=name,driver_version --format=csv,noheader 2>/dev/null)
  info "GPU: $GPU"
  modinfo nvidia 2>/dev/null | grep -q 'license:.*Dual MIT/GPL' && ok "NVIDIA open kernel driver (required for RTX 50)" \
    || warn "Not on nvidia-open. RTX 50 cards need it: sudo pacman -S linux-cachyos-nvidia-open"
  BAR=$(nvidia-smi -q -d MEMORY 2>/dev/null | awk '/BAR1 Memory Usage/{f=1} f&&/Total/{print $3; exit}')
  if [[ -n "$BAR" && "$BAR" -gt 1024 ]]; then ok "Resizable BAR on (${BAR} MiB)"
  else warn "Resizable BAR looks OFF (BAR1 ${BAR:-?} MiB). Turn on 'Re-Size BAR' + 'Above 4G Decoding' in BIOS."; fi
  PCIE=$(nvidia-smi --query-gpu=pcie.link.gen.max,pcie.link.width.max --format=csv,noheader 2>/dev/null | tr -d ' ')
  [[ -n "$PCIE" ]] && info "GPU PCIe max: Gen ${PCIE/,/ x}"
else
  warn "nvidia-smi not found; NVIDIA driver not installed?"
fi

if have dmidecode; then
  MHZ=$(sudo dmidecode -t 17 2>/dev/null | awk -F: '/Configured Memory Speed/ && $2 ~ /[0-9]/{gsub(/[^0-9]/,"",$2); print $2; exit}')
  if [[ -n "$MHZ" ]]; then
    (( MHZ >= 5600 )) && ok "RAM at ${MHZ} MT/s (EXPO on)" || warn "RAM at ${MHZ} MT/s. Enable EXPO in BIOS (most DDR5 kits: 6000 MT/s)."
  fi
fi

for n in "$R"/sys/class/nvme/nvme*; do
  [[ -d "$n" ]] || continue
  M=$(cat "$n/model" 2>/dev/null | xargs); L=$(cat "$n/device/current_link_speed" 2>/dev/null)
  info "NVMe: $M · ${L:-?}"
done

NICS=()
for i in /sys/class/net/*; do
  n=$(basename "$i"); [[ -e "$i/device" && ! -d "$i/wireless" && "$(cat "$i/type" 2>/dev/null)" == 1 ]] || continue
  NICS+=("$n")
  S=$(cat "$i/speed" 2>/dev/null); D=$(basename "$(readlink -f "$i/device/driver" 2>/dev/null)")
  if [[ "${S:-0}" -ge 2500 ]]; then ok "Ethernet $n: ${S} Mb/s ($D)"
  elif [[ "${S:-0}" -gt 0 ]]; then warn "Ethernet $n linked at only ${S} Mb/s ($D). Check the cable (Cat5e or better) and router port."
  else info "Ethernet $n ($D): no link"; fi
done

[[ "${XDG_SESSION_TYPE:-}" == wayland ]] && ok "Wayland session" || info "Session: ${XDG_SESSION_TYPE:-unknown} (Wayland recommended on Plasma 6)"
boot_report

if [[ $CHECK == 1 ]]; then
  printf '\n  %s%d thing(s) to look at.%s Run without --check to apply the tuning.\n\n' "$c_b" "$WARNS" "$c_0"; exit 0
fi

# ======================================================================= APPLY
MANIFEST="$R/etc/crazyos-turbo.manifest"; sudo mkdir -p "$R/etc"
sudo rm -f "$MANIFEST.tmp"; sudo touch "$MANIFEST.tmp"; sudo chmod 666 "$MANIFEST.tmp"

step "Installing gaming tools"
if [[ -z "$R" ]]; then
  sudo pacman -S --needed --noconfirm ethtool mangohud lib32-mangohud proton-cachyos dmidecode \
    && ok "ethtool, MangoHud, proton-cachyos" || warn "Some packages failed; continuing"
fi

step "Kernel & memory tuning"
MEMKB=$(awk '/MemTotal/{print $2}' /proc/meminfo)
MINFREE=$(( MEMKB >= 30000000 ? 524288 : 262144 ))
put /etc/sysctl.d/99-crazyos-turbo.conf <<EOF
# CrazyOS Turbo — adds to /usr/lib/sysctl.d/70-cachyos-settings.conf, does not repeat it.

## Network: BBR congestion control with fq pacing, buffers sized for 2.5 GbE downloads (Steam, updates)
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.core.rmem_max = 33554432
net.core.wmem_max = 33554432
net.ipv4.tcp_rmem = 4096 131072 33554432
net.ipv4.tcp_wmem = 4096 65536 33554432
net.core.netdev_max_backlog = 16384
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0

## Games that hit split locks are not throttled by the kernel
kernel.split_lock_mitigate = 0

## Avoid memory-reclaim stalls mid-game (SteamOS-style)
vm.compaction_proactiveness = 0
vm.watermark_boost_factor = 1
vm.min_free_kbytes = $MINFREE
vm.max_map_count = 2147483642
EOF
put /etc/modules-load.d/crazyos-turbo.conf <<'EOF'
tcp_bbr
EOF
ok "BBR networking, split-lock fix, no reclaim stalls"

put /etc/tmpfiles.d/crazyos-turbo.conf <<'EOF'
# PCIe link power saving off: no wake-up delay on the GPU, NVMe and NIC links
w- /sys/module/pcie_aspm/parameters/policy - - - - performance
EOF
ok "PCIe power saving off"

step "Input latency"
put /etc/udev/rules.d/99-crazyos-turbo.rules <<'EOF'
# USB devices (mouse, keyboard, pads, headsets) never autosuspend, so the first input is never delayed
ACTION=="add", SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", TEST=="power/control", ATTR{power/control}="on"
# Desktop GPU stays fully awake (overrides CachyOS's laptop-friendly runtime PM)
ACTION=="add|bind", SUBSYSTEM=="pci", DRIVERS=="nvidia", ATTR{vendor}=="0x10de", ATTR{class}=="0x03[0-9]*", TEST=="power/control", ATTR{power/control}="on"
EOF
ok "USB and GPU never nap"

step "NVIDIA RTX 5080"
put /etc/modprobe.d/99-crazyos-turbo-nvidia.conf <<'EOF'
# Page Attribute Table: faster CPU<->GPU memory mapping
options nvidia NVreg_UsePageAttributeTable=1
EOF
put /etc/environment.d/90-crazyos-turbo.conf <<'EOF'
# 12 GB shader cache that never gets trimmed: fewer shader-compile stutters after the first run
__GL_SHADER_DISK_CACHE_SIZE=12000000000
__GL_SHADER_DISK_CACHE_SKIP_CLEANUP=1
EOF
ok "PAT on, big persistent shader cache"

step "Wired network: 2.5 GbE low latency"
sudo mkdir -p "$R/usr/local/lib/crazyos-turbo"
put /usr/local/lib/crazyos-turbo/nic-tune <<'EOF'
#!/bin/sh
# Energy-Efficient Ethernet off (it adds wake-up latency and causes spikes on RTL8125 / I226-V),
# interrupt moderation down so packets reach the game sooner.
for i in /sys/class/net/*; do
  n=${i##*/}
  [ -e "$i/device" ] && [ ! -d "$i/wireless" ] && [ "$(cat "$i/type")" = 1 ] || continue
  ethtool --set-eee "$n" eee off 2>/dev/null
  ethtool -C "$n" adaptive-rx off rx-usecs 8 2>/dev/null || ethtool -C "$n" rx-usecs 8 2>/dev/null
  ethtool -K "$n" gro on gso on tso on 2>/dev/null
done
exit 0
EOF
sudo chmod 755 "$R/usr/local/lib/crazyos-turbo/nic-tune"
put /etc/systemd/system/crazyos-turbo-nic.service <<'EOF'
[Unit]
Description=CrazyOS Turbo: low-latency wired network
After=network-pre.target
Wants=network-pre.target

[Service]
Type=oneshot
ExecStart=/usr/local/lib/crazyos-turbo/nic-tune
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
put /etc/NetworkManager/dispatcher.d/90-crazyos-turbo <<'EOF'
#!/bin/sh
# Re-apply after every cable/link change
[ "$2" = "up" ] && /usr/local/lib/crazyos-turbo/nic-tune
exit 0
EOF
sudo chmod 755 "$R/etc/NetworkManager/dispatcher.d/90-crazyos-turbo"
ok "EEE off, faster interrupts, re-applied on every link-up"

step "Game launcher: gamefast"
put /usr/local/bin/gamefast <<'EOF'
#!/usr/bin/env bash
# Steam launch options:   gamefast %command%
#   -l          competitive low-latency mode (dxvk-low-latency + Vulkan Reflex layer)
#   -f <fps>    cap the frame rate (use refresh - 3, e.g. -f 141 on 144 Hz, -f 237 on 240 Hz)
#   -h          show the MangoHud overlay
# Always: CPU performance mode while the game runs, latest DLSS DLLs and preset.
LOW=0 FPS="" HUD=0
while [[ "${1:-}" == -* ]]; do
  case "$1" in
    -l) LOW=1 ;;
    -f) FPS="$2"; shift ;;
    -h) HUD=1 ;;
    --) shift; break ;;
  esac
  shift
done
export PROTON_DLSS_UPGRADE="${PROTON_DLSS_UPGRADE:-1}"
if [[ $LOW == 1 ]]; then
  export PROTON_DXVK_LOWLATENCY="${PROTON_DXVK_LOWLATENCY:-1}"
  export DXVK_NVAPI_VKREFLEX="${DXVK_NVAPI_VKREFLEX:-1}"
fi
if [[ -n "$FPS" || $HUD == 1 ]]; then
  export MANGOHUD=1
  cfg=""; [[ $HUD == 1 ]] || cfg="no_display"
  [[ -n "$FPS" ]] && cfg="${cfg:+$cfg,}fps_limit=$FPS"
  export MANGOHUD_CONFIG="${MANGOHUD_CONFIG:-$cfg}"
fi
if command -v game-performance >/dev/null; then exec game-performance "$@"; else exec "$@"; fi
EOF
sudo chmod 755 "$R/usr/local/bin/gamefast"
ok "gamefast installed"

step "Fast boot"
mod() {  # back up a file before editing it in place; turbo-restore.sh puts the original back
  local f="$R$1"; [[ -f "$f" ]] || return 1
  [[ -f "$f.crazyos-bak" ]] || sudo cp -a "$f" "$f.crazyos-bak"
  echo "MOD:$1" >> "$MANIFEST.tmp"
}
mkdir -p "$HOME/.local/share/crazyos"
if have systemd-analyze && [[ ! -f "$HOME/.local/share/crazyos/boot-before.txt" ]]; then
  systemd-analyze 2>/dev/null | head -1 > "$HOME/.local/share/crazyos/boot-before.txt"
fi
BL=0
for L in /boot/limine.conf /boot/EFI/limine/limine.conf /efi/limine.conf /boot/efi/limine.conf; do
  [[ -f "$R$L" ]] || continue
  mod "$L"
  if sudo grep -qiE '^\s*timeout\s*[:=]' "$R$L"; then
    sudo sed -i -E 's/^(\s*)timeout:.*/\1timeout: 1/; s/^(\s*)TIMEOUT=.*/\1TIMEOUT=1/' "$R$L"
  else
    sudo sed -i '1i timeout: 1' "$R$L"
  fi
  sudo sed -i -E 's/^(\s*)(wallpaper:.*)$/\1# \2   # off: CrazyOS Turbo (slow to load on new hardware)/' "$R$L"
  ok "Limine boot menu: 1 second, no slow splash image ($L)"; BL=1
done
for L in /boot/loader/loader.conf /efi/loader/loader.conf /boot/efi/loader/loader.conf; do
  [[ -f "$R$L" ]] || continue
  mod "$L"
  if sudo grep -qE '^\s*timeout' "$R$L"; then sudo sed -i -E 's/^\s*timeout.*/timeout 1/' "$R$L"; else echo "timeout 1" | sudo tee -a "$R$L" >/dev/null; fi
  ok "systemd-boot menu: 1 second ($L)"; BL=1
done
if [[ -f "$R/etc/default/grub" && $BL == 0 ]]; then
  mod /etc/default/grub
  sudo sed -i -E "s/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT='1'/" "$R/etc/default/grub"
  [[ -z "$R" ]] && sudo grub-mkconfig -o /boot/grub/grub.cfg >/dev/null 2>&1
  ok "GRUB menu: 1 second"
fi
if [[ -z "$R" ]]; then
  for svc in NetworkManager-wait-online.service systemd-networkd-wait-online.service; do
    if systemctl is-enabled "$svc" 2>/dev/null | grep -qx enabled; then
      sudo systemctl disable "$svc" >/dev/null 2>&1 && echo "SVC:$svc" >> "$MANIFEST.tmp" && ok "Boot no longer waits for the network ($svc)"
    fi
  done
  sudo pacman -S --needed --noconfirm lz4 >/dev/null 2>&1
fi
printf '# Boot image compressed with lz4: a little bigger, but it unpacks fastest at boot\nCOMPRESSION="lz4"\n' | put /etc/mkinitcpio.conf.d/90-crazyos-turbo.conf
ok "Boot image uses fast lz4 compression"
if [[ $AUTOLOGIN == 1 ]]; then
  U="${SUDO_USER:-$USER}"
  printf '[Autologin]\nUser=%s\nSession=plasma.desktop\nRelogin=false\n' "$U" | put /etc/plasmalogin.conf.d/90-crazyos-autologin.conf
  printf '[Autologin]\nUser=%s\nSession=plasma\nRelogin=false\n' "$U" | put /etc/sddm.conf.d/90-crazyos-autologin.conf
  warn "Autologin is on for $U: anyone who switches the PC on gets your desktop, and KDE Wallet may ask for your password once after login."
fi

if [[ $ALWAYS == 1 && -z "$R" ]]; then
  powerprofilesctl set performance 2>/dev/null && ok "CPU always in performance mode" || warn "Could not set performance profile"
fi

if [[ $SCX == 1 ]]; then
  step "CPU scheduler: scx_lavd (gaming)"
  [[ -f "$R/etc/scx_loader.toml" && ! -f "$R/etc/scx_loader.toml.turbo-backup" ]] && sudo cp "$R/etc/scx_loader.toml" "$R/etc/scx_loader.toml.turbo-backup"
  printf 'default_sched = "scx_lavd"\ndefault_mode = "Gaming"\n' | put /etc/scx_loader.toml
  [[ -z "$R" ]] && { sudo pacman -S --needed --noconfirm scx-scheds >/dev/null 2>&1; sudo systemctl enable --now scx_loader.service >/dev/null 2>&1; }
  ok "scx_lavd in Gaming mode (switch back any time in CachyOS Kernel Manager)"
fi

step "Activating"
sudo mv "$MANIFEST.tmp" "$MANIFEST"; sudo chmod 644 "$MANIFEST"
if [[ -z "$R" ]]; then
  sudo sysctl --system >/dev/null 2>&1 && ok "Kernel settings live"
  sudo systemd-tmpfiles --create /etc/tmpfiles.d/crazyos-turbo.conf >/dev/null 2>&1
  sudo udevadm control --reload && sudo udevadm trigger --subsystem-match=usb --action=add >/dev/null 2>&1
  sudo systemctl daemon-reload && sudo systemctl enable --now crazyos-turbo-nic.service >/dev/null 2>&1 && ok "Network tuning live"
  sudo mkinitcpio -P >/dev/null 2>&1 && ok "Boot image rebuilt (NVIDIA option)" || warn "mkinitcpio failed; run: sudo mkinitcpio -P"
fi

printf '\n%s  Files added%s (all removed by ./turbo-restore.sh):\n' "$c_b" "$c_0"
sed 's/^/    /' "$MANIFEST"
printf '\n  %sReboot once.%s Then in Steam, for each game:\n' "$c_b" "$c_0"
printf '    Properties → Compatibility → %sproton-cachyos%s\n' "$c_g" "$c_0"
printf '    Launch options → %sgamefast %%command%%%s   (competitive: %sgamefast -l -f 237 %%command%%%s)\n' "$c_g" "$c_0" "$c_g" "$c_0"
printf '  And turn on NVIDIA Reflex (On + Boost) inside games that have it.\n'
printf '  After rebooting, check the new boot time with:  %scrazyos-turbo --boot-report%s\n\n' "$c_g" "$c_0"

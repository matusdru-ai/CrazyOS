#!/bin/bash
# Runs inside an Arch Linux container on GitHub Actions (same approach CachyOS uses for its own ISOs).
set -euo pipefail

# CachyOS package signing key + repo, so the ISO's CachyOS packages can be verified
pacman-key --init
pacman-key --recv-keys F3B607488DB35A47 --keyserver keyserver.ubuntu.com
pacman-key --lsign-key F3B607488DB35A47
grep -q '^\[cachyos\]' /etc/pacman.conf || \
  sed -i '/^\[core\]$/i[cachyos]\nServer = https://mirror.cachyos.org/repo/$arch/$repo\n' /etc/pacman.conf
pacman -Syu --noconfirm --needed archiso mkinitcpio-archiso squashfs-tools grub git python sudo cachyos-keyring

# The kit refuses to run as root, so build as a normal user with passwordless sudo
id builder >/dev/null 2>&1 || useradd -m builder
echo "builder ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/builder
chown -R builder: /kit
sudo -H -u builder env GITHUB_ACTIONS=true WORK=/kit/build bash /kit/build-iso.sh

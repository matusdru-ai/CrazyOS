#!/usr/bin/env bash
# Builds CrazyOS: the official CachyOS desktop ISO, rebranded, with the liquid-glass look
# in the live session, and the glass look + Turbo offered on first login after install.
#
# Run on a CachyOS (or Arch) PC as your normal user:   ./build-iso.sh
# Needs ~20 GB free disk, internet, and 15–40 minutes.
# Result:  ./out/crazyos-YYYYMMDD.iso  (+ .sha256)
set -euo pipefail

KIT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
WORK="${WORK:-$KIT/build}"
REPO="$WORK/cachyos-live-iso"
c_c=$'\e[38;5;117m\e[1m' c_g=$'\e[38;5;79m' c_r=$'\e[38;5;203m' c_0=$'\e[0m'
step() { printf '\n%s◆ %s%s\n' "$c_c" "$*" "$c_0"; }
ok()   { printf '  %s✓%s %s\n' "$c_g" "$c_0" "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '%s✗ %s%s\n' "$c_r" "$*" "$c_0"; exit 1; }

[[ $EUID -eq 0 ]] && die "Run as your normal user; it asks for sudo when needed."
command -v pacman >/dev/null || die "Run this on CachyOS or Arch Linux."
FREE=$(df -Pk "$KIT" | awk 'NR==2{print int($4/1024/1024)}')
if [[ -z "${GITHUB_ACTIONS:-}" ]]; then
  (( FREE >= 20 )) || die "Need about 20 GB free here (have ${FREE} GB). Set WORK=/path/with/space to build elsewhere."
fi

step "Installing build tools"
sudo pacman -S --needed --noconfirm archiso mkinitcpio-archiso git squashfs-tools grub python
ok "archiso ready"

step "Getting the official CachyOS ISO recipe"
rm -rf "$REPO"; mkdir -p "$WORK"
git clone -q --depth 1 https://github.com/CachyOS/CachyOS-Live-ISO.git "$REPO"
ISO="$REPO/archiso"; ROOT="$ISO/airootfs"
ok "$(git -C "$REPO" log -1 --format='%h %cs')"

step "Adding packages to the live image"
sed -i '/^cachyos-hello$/d' "$ISO/packages_desktop.x86_64"   # CrazyOS Welcome replaces it
# boost-libs + python: Calamares links against libboost_python but the package does not always pull it in
for p in kvantum inter-font ttf-jetbrains-mono-nerd boost-libs python kdialog; do
  grep -qx "$p" "$ISO/packages_desktop.x86_64" || echo "$p" >> "$ISO/packages_desktop.x86_64"
done
ok "kvantum, Inter, JetBrains Mono Nerd Font, installer libraries"

step "Pre-building Darkly and Better Blur DX for the live session (optional)"
LOCAL="$WORK/localrepo"; rm -rf "$LOCAL" "$WORK/aur"; mkdir -p "$LOCAL" "$WORK/aur"
for p in darkly kwin-effects-better-blur-dx; do
  if git clone -q --depth 1 "https://aur.archlinux.org/$p.git" "$WORK/aur/$p" \
     && (cd "$WORK/aur/$p" && makepkg -s -f --noconfirm --needed >/dev/null 2>&1); then
    find "$WORK/aur/$p" -maxdepth 1 -name "*.pkg.tar.zst" ! -name "*-debug-*" -exec cp {} "$LOCAL/" \;
    ok "$p"
  else
    printf '  ! %s did not build; the live session uses the fallback for it\n' "$p"
  fi
done
if compgen -G "$LOCAL/*.pkg.tar.zst" >/dev/null; then
  repo-add -q "$LOCAL/crazyos-local.db.tar.gz" "$LOCAL"/*.pkg.tar.zst
  printf '\n[crazyos-local]\nSigLevel = Optional TrustAll\nServer = file://%s\n' "$LOCAL" >> "$ISO/pacman.conf"
  for f in "$LOCAL"/*.pkg.tar.zst; do
    n="$(basename "$f" | sed -E 's/-[^-]+-[^-]+-[^-]+\.pkg\.tar\.zst$//')"
    grep -qx "$n" "$ISO/packages_desktop.x86_64" || echo "$n" >> "$ISO/packages_desktop.x86_64"
  done
  ok "Added to the live image: $(ls "$LOCAL" | grep -c '\.pkg\.tar\.zst$') package(s)"
fi

step "Bundling WhiteSur Liquid theme, icons and cursors"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/src" "$T/home/.local/share" "$T/home/.config/Kvantum"
for r in WhiteSur-kde WhiteSur-icon-theme WhiteSur-cursors; do
  git clone -q --depth 1 "https://github.com/vinceliuice/$r.git" "$T/src/$r"
done
(cd "$T/src/WhiteSur-kde"        && HOME="$T/home" ./install.sh -c dark   >/dev/null)
(cd "$T/src/WhiteSur-icon-theme" && HOME="$T/home" ./install.sh -t default >/dev/null)
(cd "$T/src/WhiteSur-cursors"    && HOME="$T/home" ./install.sh            >/dev/null)
DEST="$ROOT/usr/share/crazyos"
mkdir -p "$DEST/themes/local-share" "$DEST/themes/kvantum"
cp -r "$T/home/.local/share/." "$DEST/themes/local-share/"
cp -r "$T/home/.config/Kvantum/." "$DEST/themes/kvantum/"
mkdir -p "$DEST/themes/gtk"
curl -fsSL --max-time 120 -o "$T/gtk.tar.xz" https://github.com/vinceliuice/WhiteSur-gtk-theme/raw/master/release/WhiteSur-Dark.tar.xz \
  && tar -xJf "$T/gtk.tar.xz" -C "$DEST/themes/gtk/" || printf '  ! GTK theme download failed; it will be fetched at setup time instead\n'
ok "$(du -sh "$DEST/themes" | cut -f1) of themes (Plasma, Kvantum, GTK, icons, cursors)"

step "Adding the Glass kit"
cp -r "$KIT/glass-setup.sh" "$KIT/glass-restore.sh" "$KIT/turbo-setup.sh" "$KIT/turbo-restore.sh" "$KIT/files" "$DEST/"
chmod 755 "$DEST"/*.sh "$DEST/files/calamares-hook.sh"
mkdir -p "$ROOT/usr/local/bin"
printf '#!/bin/sh\nexec /usr/share/crazyos/glass-setup.sh "$@"\n' > "$ROOT/usr/local/bin/crazyos-glass"
printf '#!/bin/sh\nexec /usr/share/crazyos/turbo-setup.sh "$@"\n' > "$ROOT/usr/local/bin/crazyos-turbo"
cat >> "$ISO/profiledef.sh" <<'EOF'
file_permissions+=(
  ["/usr/local/bin/crazyos-glass"]="0:0:755"
  ["/usr/share/crazyos/glass-setup.sh"]="0:0:755"
  ["/usr/share/crazyos/glass-restore.sh"]="0:0:755"
  ["/usr/local/bin/crazyos-turbo"]="0:0:755"
  ["/usr/local/bin/crazyos-install"]="0:0:755"
  ["/usr/share/crazyos/turbo-setup.sh"]="0:0:755"
  ["/usr/share/crazyos/turbo-restore.sh"]="0:0:755"
  ["/usr/share/crazyos/files/calamares-hook.sh"]="0:0:755"
  ["/usr/share/crazyos/files/installer/fix-installer-libs.sh"]="0:0:755"
  ["/usr/local/bin/crazyos-welcome"]="0:0:755"
  ["/usr/share/crazyos/files/installer/add-repo.sh"]="0:0:755"
  ["/usr/share/crazyos/files/installer/target-setup.sh"]="0:0:755"
  ["/usr/share/crazyos/files/brand-themes.sh"]="0:0:755"
  ["/usr/share/crazyos/files/os-release.sh"]="0:0:755"
)
EOF
# Live session: apply the look automatically at login
mkdir -p "$ROOT/etc/skel/.config/autostart"
cp "$KIT/files/crazyos-live.desktop" "$ROOT/etc/skel/.config/autostart/"
# CrazyOS Welcome instead of CachyOS Hello
install -m755 "$KIT/files/welcome/crazyos-welcome" "$ROOT/usr/local/bin/crazyos-welcome"
install -Dm644 "$KIT/files/welcome/crazyos-welcome.desktop" "$ROOT/usr/share/applications/crazyos-welcome.desktop"
cp "$KIT/files/welcome/crazyos-welcome.desktop" "$ROOT/etc/skel/.config/autostart/"
mkdir -p "$ROOT/etc/xdg/autostart"
printf '[Desktop Entry]\nType=Application\nName=CachyOS Hello\nHidden=true\n' > "$ROOT/etc/xdg/autostart/cachyos-hello.desktop"
ok "Live session will boot straight into the glass look; Turbo is offered after install"

step "Making the live USB CrazyOS from the first second"
# Themes system-wide (hard links: no extra space on the ISO)
cp -al "$DEST/themes/local-share/." "$ROOT/usr/share/" 2>/dev/null || cp -r "$DEST/themes/local-share/." "$ROOT/usr/share/"
mkdir -p "$ROOT/usr/share/Kvantum" "$ROOT/usr/share/themes" "$ROOT/usr/share/color-schemes"
cp -al "$DEST/themes/kvantum/." "$ROOT/usr/share/Kvantum/" 2>/dev/null || true
[[ -d "$DEST/themes/gtk/WhiteSur-Dark" ]] && cp -al "$DEST/themes/gtk/WhiteSur-Dark" "$ROOT/usr/share/themes/" 2>/dev/null
cp "$KIT/files/colors/CrazyOS.colors" "$ROOT/usr/share/color-schemes/"
bash "$KIT/files/brand-themes.sh" "$ROOT/usr/share" "$KIT/files/branding"   # CrazyOS logo, not Apple's
W="$ROOT/usr/share/wallpapers/CrazyOS"; mkdir -p "$W/contents/images"
cp "$KIT/files/wallpaper/3840x2160.png" "$W/contents/images/"
printf '{"KPlugin":{"Id":"CrazyOS","Name":"CrazyOS","Authors":[{"Name":"CrazyOS"}],"License":"CC-BY-SA-4.0"}}\n' > "$W/metadata.json"
# Default user settings: start from CachyOS's defaults and switch them to CrazyOS
git clone -q --depth 1 https://github.com/CachyOS/cachyos-kde-settings.git "$T/cks" 2>/dev/null || mkdir -p "$T/cks"
HAS_DARKLY=0; compgen -G "$LOCAL/darkly-*.pkg.tar.zst" >/dev/null && HAS_DARKLY=1
python3 "$KIT/files/preseed.py" "$ROOT" "$KIT" "$T/cks" "$HAS_DARKLY" >/dev/null && ok "Glass look, wallpaper and fonts set before the desktop appears" \
  || printf '  ! Pre-set look failed; the live session applies it after login instead\n'
# Name
echo crazyos > "$ROOT/etc/hostname"
[[ -f "$ROOT/etc/os-release" ]] && sed -i -E 's/^NAME=.*/NAME="CrazyOS"/; s/^PRETTY_NAME=.*/PRETTY_NAME="CrazyOS"/; s/^LOGO=.*/LOGO=crazyos/' "$ROOT/etc/os-release"
ok "Computer name and system name: CrazyOS"

# Installer: CrazyOS launcher replaces CachyOS's slow pre-launch script (CachyOS Hello's
# "Launch installer" button uses the same path), plus an "Install CrazyOS" app entry.
install -m755 "$KIT/files/installer/crazyos-install" "$ROOT/usr/local/bin/crazyos-install"
install -m755 "$KIT/files/installer/crazyos-install" "$ROOT/usr/local/bin/calamares-online.sh"
install -Dm644 "$KIT/files/installer/crazyos-install.desktop" "$ROOT/usr/share/applications/crazyos-install.desktop"
install -Dm644 "$KIT/files/branding/crazyos.svg" "$ROOT/usr/share/icons/hicolor/scalable/apps/crazyos.svg"
install -Dm644 "$KIT/files/branding/crazyos-symbolic.svg" "$ROOT/usr/share/icons/hicolor/scalable/apps/crazyos-symbolic.svg"
ok "Installer opens instantly, with CrazyOS branding and a slideshow"

step "CrazyOS branding"
# Visible boot-menu text only; kernel paths, ids and labels stay untouched
sed -i -E '/^menuentry "/ s/^(menuentry "[^"]*)CachyOS/\1CrazyOS/' "$ISO/grub/grub.cfg" "$ISO/grub/loopback.cfg"
for f in "$ISO"/syslinux/*.cfg; do
  sed -i -E '/^[[:space:]]*(LINUX|INITRD|APPEND|LABEL|KERNEL)[[:space:]]/! s/CachyOS/CrazyOS/g' "$f"
done
sed -i -E '/^title/ s/CachyOS/CrazyOS/' "$ISO"/efiboot/loader/entries/*.conf
cp "$KIT/files/branding/splash.png"  "$ISO/grub/splash.png"
cp "$KIT/files/branding/splash.png"  "$ISO/syslinux/splash.png"
cp "$KIT/files/branding/splash1.png" "$ISO/syslinux/splash1.png"
sed -i -E 's|^iso_publisher=.*|iso_publisher="CrazyOS (built on CachyOS)"|; s|^iso_application=.*|iso_application="CrazyOS Live/Rescue"|' "$ISO/profiledef.sh"
ok "Boot menu and splash say CrazyOS"

# CachyOS Hello flags any ISO whose date tag differs from the official release as "testing".
# CrazyOS is built from the current recipe, so tag it with the current official version.
VER="$(curl -fsSL --max-time 15 https://cachyos.org/versions.json 2>/dev/null \
  | python3 -c 'import json,sys; print(json.load(sys.stdin)["desktopISOVersion"])' 2>/dev/null || true)"
if [[ "$VER" =~ ^[0-9]{6}$ ]]; then
  sed -i "s|echo \"\${_version}\" > \${src_dir}/archiso/airootfs/etc/version-tag|echo \"$VER\" > \${src_dir}/archiso/airootfs/etc/version-tag|" "$REPO/util-iso.sh"
  ok "Version tag $VER (no 'testing ISO' warning in the installer)"
fi

step "Checking the installer's libraries"
PC="$WORK/pkgcache"; mkdir -p "$PC" "$WORK/calcheck"
CALPKG="$(grep -E '^(cachyos-)?calamares' "$ISO/packages_desktop.x86_64" | head -n1)"; CALPKG="${CALPKG:-cachyos-calamares-next}"
sudo pacman -Sw --noconfirm --cachedir "$PC" "$CALPKG" >/dev/null 2>&1 || true
f="$(ls -1t "$PC"/"$CALPKG"-*.pkg.tar.zst 2>/dev/null | head -n1)"
if [[ -n "$f" ]]; then
  bsdtar -xf "$f" -C "$WORK/calcheck" 2>/dev/null
  BOOSTVER="$(pacman -Si extra/boost-libs 2>/dev/null | awk -F': ' '/^Version/{print $2}' | cut -d- -f1)"
  NEED="$(find "$WORK/calcheck" -type f \( -name '*.so*' -o -path '*/bin/*' \) -exec readelf -d {} + 2>/dev/null \
          | grep -o 'libboost_[a-z0-9_]*\.so\.[0-9.]*' | sort -u)"
  OLD=""; for so in $NEED; do [[ "${so##*.so.}" == "$BOOSTVER" ]] || OLD="$OLD $so"; done
  if [[ -n "$OLD" ]]; then
    warn "Installer was built for an older Boost than Arch ships ($BOOSTVER). Adding:$OLD"
    sudo bash "$KIT/files/installer/fix-installer-libs.sh" "$ROOT" $OLD || warn "Couldn't add all of them; the installer will try again on the live USB"
  else
    ok "Installer libraries match"
  fi
else
  warn "Couldn't download $CALPKG to check it; the installer will check itself on the live USB"
fi

step "Building the ISO (this is the long part)"
cd "$REPO"
sudo ./buildiso.sh -p desktop -v -w

step "Collecting the result"
mkdir -p "$KIT/out"
SRC_ISO="$(find "$REPO/out" -name '*.iso' -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)"
[[ -n "$SRC_ISO" ]] || die "No ISO produced. Check the log in $REPO/out or $REPO/build."
OUT="$KIT/out/crazyos-$(date +%Y%m%d).iso"
sudo mv "$SRC_ISO" "$OUT"; sudo chown "$USER": "$OUT"
(cd "$KIT/out" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256")
ok "$OUT  ($(du -h "$OUT" | cut -f1))"
printf '\nFlash it with Ventoy, Rufus (DD mode) or:\n  sudo dd if=%s of=/dev/sdX bs=4M status=progress oflag=sync\n\n' "$OUT"

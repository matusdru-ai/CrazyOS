#!/usr/bin/env bash
# CrazyOS — turns a CachyOS KDE Plasma 6 desktop into a liquid-glass look.
#
#   ./glass-setup.sh              full setup (asks before changing your panels)
#   ./glass-setup.sh --yes        don't ask, do everything
#   ./glass-setup.sh --no-aur     skip the Better Blur DX effect (stock KWin blur instead)
#   ./glass-setup.sh --rounded    also install the Rounded Corners KWin effect (AUR)
#   ./glass-setup.sh --no-layout  keep your current panels
#   ./glass-setup.sh --live       used by the custom ISO's live session (no installs)
#   ./glass-setup.sh --first-run  used once after installing from the custom ISO (asks first)
#   ./glass-setup.sh --auto       first login on an installed CrazyOS (no questions)
#
# Every KDE config file it touches is backed up first. Undo with ./glass-restore.sh
set -uo pipefail

KIT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
STATE="$HOME/.local/share/crazyos"
SRC="$HOME/.cache/crazyos/src"
WALL_DIR="$HOME/.local/share/wallpapers/CrazyOS"

YES=0 AUR=1 ROUNDED=0 LAYOUT=1 LIVE=0 FIRST=0 AUTO=0
for a in "$@"; do
  case "$a" in
    --yes|-y) YES=1 ;;
    --no-aur) AUR=0 ;;
    --rounded) ROUNDED=1 ;;
    --no-layout) LAYOUT=0 ;;
    --live) LIVE=1; YES=1; AUR=0 ;;
    --first-run) FIRST=1 ;;
    --auto) LIVE=1; YES=1; AUTO=1 ;;   # behaves like the live session: everything is already installed
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "Unknown option: $a (try --help)"; exit 1 ;;
  esac
done

c_b=$'\e[1m' c_c=$'\e[38;5;117m' c_g=$'\e[38;5;79m' c_y=$'\e[38;5;221m' c_r=$'\e[38;5;203m' c_0=$'\e[0m'
step() { printf '\n%s◆ %s%s\n' "$c_c$c_b" "$*" "$c_0"; }
ok()   { printf '  %s✓%s %s\n' "$c_g" "$c_0" "$*"; }
warn() { printf '  %s!%s %s\n' "$c_y" "$c_0" "$*"; }
die()  { printf '%s✗ %s%s\n' "$c_r" "$*" "$c_0"; exit 1; }
ask()  { [[ $YES == 1 ]] && return 0; local r; read -r -p "  $1 [Y/n] " r; [[ -z "$r" || "$r" =~ ^[Yy] ]]; }
have() { command -v "$1" >/dev/null 2>&1; }
kw()   { kwriteconfig6 "$@" 2>/dev/null || warn "could not write: $*"; }

QDBUS=""
for q in qdbus6 qdbus-qt6 /usr/lib/qt6/bin/qdbus qdbus; do have "$q" && { QDBUS="$q"; break; }; done

# ---------------------------------------------------------------- first run
if [[ $FIRST == 1 ]]; then
  [[ -f "$STATE/done" ]] && exit 0
  mkdir -p "$STATE"
  printf '\n%s  CrazyOS%s\n  Make this desktop glass? It needs internet and your password.\n' "$c_c$c_b" "$c_0"
  if ! ask "Set it up now?"; then
    touch "$STATE/done"; echo "  Skipped. Run 'crazyos-glass' any time."; sleep 2; exit 0
  fi
fi

# ---------------------------------------------------------------- checks
[[ $EUID -eq 0 ]] && die "Run as your normal user, not root (it uses sudo when needed)."
have pacman || die "This is meant for CachyOS / Arch Linux."
have kwriteconfig6 || die "KDE Plasma 6 not found. Install the CachyOS KDE edition first."
[[ "${XDG_CURRENT_DESKTOP:-}" == *KDE* ]] || warn "You don't seem to be in a Plasma session; settings apply on next login."

printf '\n%s  ░ CrazyOS ░%s\n' "$c_c$c_b" "$c_0"
mkdir -p "$STATE"
exec > >(tee -a "$STATE/setup.log") 2>&1
echo "  log: $STATE/setup.log ($(date))"
if [[ $LIVE == 1 && -n "$QDBUS" ]]; then
  # Let Plasma and CachyOS's own first-login setup finish before we restyle anything
  for _ in $(seq 1 60); do "$QDBUS" org.kde.plasmashell >/dev/null 2>&1 && break; sleep 1; done
  sleep 8
fi

# ---------------------------------------------------------------- backup
step "Backing up your current KDE settings"
BK="$STATE/backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
for f in kdeglobals kwinrc kcminputrc plasmarc plasmashellrc plasma-org.kde.plasma.desktop-appletsrc \
         kscreenlockerrc ksplashrc konsolerc Kvantum/kvantum.kvconfig; do
  [[ -f "$HOME/.config/$f" ]] && { mkdir -p "$BK/$(dirname "$f")"; cp -a "$HOME/.config/$f" "$BK/$f"; }
done
ok "Saved to $BK"

# ---------------------------------------------------------------- packages
if [[ $LIVE == 0 ]]; then
  step "Installing packages (Kvantum, Inter, JetBrains Mono Nerd Font)"
  sudo pacman -S --needed --noconfirm kvantum inter-font ttf-jetbrains-mono-nerd git base-devel qt6-tools \
    && ok "Packages ready" || warn "Some packages failed; continuing"
  have qdbus6 && QDBUS=qdbus6
fi

# ---------------------------------------------------------------- themes
step "Installing WhiteSur Liquid theme, icons and cursors"
mkdir -p "$HOME/.local/share" "$HOME/.config/Kvantum"
SYS_THEMES=0
[[ -d /usr/share/plasma/look-and-feel/com.github.vinceliuice.WhiteSurLiquid-dark ]] && SYS_THEMES=1
if [[ $SYS_THEMES == 1 ]]; then
  ok "Already installed system-wide (CrazyOS themes package)"
elif [[ -d "$KIT/themes/local-share" ]]; then
  cp -r "$KIT/themes/local-share/." "$HOME/.local/share/"
  cp -r "$KIT/themes/kvantum/." "$HOME/.config/Kvantum/"
  ok "Installed from the bundled copy"
else
  mkdir -p "$SRC"
  fetch() { if [[ -d "$SRC/$1/.git" ]]; then git -C "$SRC/$1" pull -q --ff-only; else git clone -q --depth 1 "https://github.com/vinceliuice/$1.git" "$SRC/$1"; fi; }
  fetch WhiteSur-kde && (cd "$SRC/WhiteSur-kde" && ./install.sh -c dark >/dev/null) && ok "Plasma theme" || warn "Plasma theme failed"
  fetch WhiteSur-icon-theme && (cd "$SRC/WhiteSur-icon-theme" && ./install.sh -t default >/dev/null) && ok "Icons" || warn "Icons failed"
  fetch WhiteSur-cursors && (cd "$SRC/WhiteSur-cursors" && ./install.sh >/dev/null) && ok "Cursors" || warn "Cursors failed"
fi
# CrazyOS logo instead of the Apple logo that ships with WhiteSur
bash "$KIT/files/brand-themes.sh" "$HOME/.local/share" "$KIT/files/branding"
rm -f "$HOME/.cache/icon-cache.kcache"
ok "CrazyOS logo in the menu, icons and loading screen"

# GTK theme for GTK apps (Firefox, CachyOS Hello, …)
mkdir -p "$HOME/.local/share/themes"
if [[ -d /usr/share/themes/WhiteSur-Dark ]]; then
  ok "GTK theme (system-wide)"
elif [[ -d "$KIT/themes/gtk/WhiteSur-Dark" ]]; then
  cp -r "$KIT/themes/gtk/WhiteSur-Dark" "$HOME/.local/share/themes/" && ok "GTK theme"
else
  T="$(mktemp -d)"
  if curl -fsSL --max-time 60 -o "$T/w.tar.xz" https://github.com/vinceliuice/WhiteSur-gtk-theme/raw/master/release/WhiteSur-Dark.tar.xz \
     && tar -xJf "$T/w.tar.xz" -C "$HOME/.local/share/themes/"; then ok "GTK theme"; else warn "GTK theme download failed"; fi
  rm -rf "$T"
fi
# Kvantum wants each theme in its own folder
for base in "$HOME/.config/Kvantum/WhiteSur" /usr/share/Kvantum/WhiteSur; do
  if [[ -f "$base/WhiteSurLiquidDark.kvconfig" ]]; then
    mkdir -p "$HOME/.config/Kvantum/WhiteSurLiquidDark"
    cp "$base"/WhiteSurLiquidDark.{kvconfig,svg} "$HOME/.config/Kvantum/WhiteSurLiquidDark/"
    break
  fi
done

# ---------------------------------------------------------------- blur effects (AUR)
BBDX=0
bbdx_present() { compgen -G "/usr/lib/qt6/plugins/kwin/effects/plugins/better_blur_dx*.so" >/dev/null; }
darkly_present() { compgen -G "/usr/lib/qt6/plugins/styles/darkly6*.so" >/dev/null; }
# On CrazyOS both come ready-built from the CrazyOS package repository
if [[ $AUR == 1 ]] && bbdx_present && darkly_present; then
  AUR=0; step "Better Blur DX and Darkly"; ok "Already installed"
fi
if [[ $AUR == 1 ]]; then
  step "Installing Better Blur DX and the Darkly app style"
  HELPER=""; for h in paru yay; do have $h && { HELPER=$h; break; }; done
  if [[ -z "$HELPER" ]]; then sudo pacman -S --needed --noconfirm paru >/dev/null 2>&1 && HELPER=paru; fi
  if [[ -n "$HELPER" ]]; then
    $HELPER -S --needed --noconfirm kwin-effects-better-blur-dx && ok "Better Blur DX installed" || warn "Better Blur DX failed to build; using stock KWin blur"
    $HELPER -S --needed --noconfirm darkly && ok "Darkly app style installed" || warn "Darkly failed to build; using Kvantum instead"
    if [[ $ROUNDED == 1 ]]; then
      $HELPER -S --needed --noconfirm kwin-effect-rounded-corners && ok "Rounded Corners installed" || warn "Rounded Corners failed"
    fi
  else
    warn "No AUR helper (paru/yay); using stock KWin blur"
  fi
fi
bbdx_present && BBDX=1
DARKLY=0; compgen -G "/usr/lib/qt6/plugins/styles/darkly6*.so" >/dev/null && DARKLY=1

# ---------------------------------------------------------------- apply look
step "Applying the glass look"
plasma-apply-lookandfeel -a com.github.vinceliuice.WhiteSurLiquid-dark >/dev/null 2>&1 && ok "Global theme" || warn "Global theme not applied"
sleep 3   # the global theme applies some defaults asynchronously; let it finish before overriding
mkdir -p "$HOME/.local/share/color-schemes"
cp "$KIT/files/colors/CrazyOS.colors" "$HOME/.local/share/color-schemes/"
if [[ $DARKLY == 1 ]]; then SCHEME=CrazyOS; else SCHEME=WhiteSurLiquidDark; fi
plasma-apply-colorscheme "$SCHEME" >/dev/null 2>&1 && ok "Colours: $SCHEME" || warn "Colour scheme not applied"
plasma-apply-desktoptheme WhiteSurLiquid-dark >/dev/null 2>&1 && ok "Translucent panels" || warn "Plasma style not applied"
if [[ -x /usr/lib/plasma-changeicons ]]; then /usr/lib/plasma-changeicons WhiteSur-dark >/dev/null 2>&1; else kw --file kdeglobals --group Icons --key Theme WhiteSur-dark; fi; ok "Icons"
plasma-apply-cursortheme WhiteSur-cursors >/dev/null 2>&1 && ok "Cursors" || kw --file kcminputrc --group Mouse --key cursorTheme WhiteSur-cursors

# App style. Darkly is preferred: native Plasma 6 style, frosted sidebars, toolbars and menus,
# and KDE apps like System Settings keep their proper layout. Kvantum is the fallback.
if [[ $DARKLY == 1 ]]; then
  kw --file kdeglobals --group KDE --key widgetStyle Darkly
  D=(--file darklyrc --group Style)
  kw --file darklyrc --group Common --key CornerRadius 10
  # Whole windows are glass: the CrazyOS colour scheme gives the window background ~65% opacity,
  # and these make toolbars, sidebars, tabs and the Dolphin view let that glass show through.
  kw "${D[@]}" --key MenuOpacity 70
  kw "${D[@]}" --key MenuBarOpacity 40
  kw "${D[@]}" --key ToolBarOpacity 40
  kw "${D[@]}" --key TabBarOpacity 50
  kw "${D[@]}" --key DolphinSidebarOpacity 45
  kw "${D[@]}" --key DolphinViewOpacity 0
  kw "${D[@]}" --key NewDolphinSelectionStyle --type bool true
  kw "${D[@]}" --key AdjustToDarkThemes --type bool true
  kw "${D[@]}" --key ViewDrawFocusIndicator --type bool false
  kw "${D[@]}" --key TabBarDrawCenteredTabs --type bool true
  ok "Darkly app style: see-through glass windows, clean settings pages"
else
  kw --file kdeglobals --group KDE --key widgetStyle kvantum
  mkdir -p "$HOME/.config/Kvantum"
  kw --file "$HOME/.config/Kvantum/kvantum.kvconfig" --group General --key theme WhiteSurLiquidDark
  KV="$HOME/.config/Kvantum/WhiteSurLiquidDark/WhiteSurLiquidDark.kvconfig"
  [[ -f "$KV" ]] && sed -i -E 's/^reduce_window_opacity=.*/reduce_window_opacity=45/; s/^translucent_windows=.*/translucent_windows=true/; s/^blurring=.*/blurring=true/' "$KV"
  ok "Kvantum glass windows"
fi
# Crisp text
kw --file kdeglobals --group General --key XftAntialias --type bool true
kw --file kdeglobals --group General --key XftHintStyle hintslight
kw --file kdeglobals --group General --key XftSubPixel rgb

# Window decoration: liquid buttons on the left, macOS style
kw --file kwinrc --group org.kde.kdecoration2 --key library org.kde.kwin.aurorae
kw --file kwinrc --group org.kde.kdecoration2 --key theme __aurorae__svg__WhiteSurLiquid-dark
kw --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnLeft XIA
kw --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnRight ""
ok "Window buttons"

# Fonts
F="Inter,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1"
kw --file kdeglobals --group General --key font "$F"
kw --file kdeglobals --group General --key menuFont "$F"
kw --file kdeglobals --group General --key toolBarFont "$F"
kw --file kdeglobals --group General --key smallestReadableFont "Inter,8,-1,5,400,0,0,0,0,0,0,0,0,0,0,1"
kw --file kdeglobals --group WM --key activeFont "Inter,10,-1,5,600,0,0,0,0,0,0,0,0,0,0,1"
kw --file kdeglobals --group General --key fixed "JetBrainsMono Nerd Font,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1"
ok "Inter + JetBrains Mono"

# Desktop effects
kw --file kdeglobals --group KDE --key AnimationDurationFactor 0.7071067811865475
kw --file kwinrc --group Plugins --key contrastEnabled --type bool true
kw --file kwinrc --group Plugins --key wobblywindowsEnabled --type bool false
if [[ $BBDX == 1 ]]; then
  G=(--file kwinrc --group Effect-better-blur-dx)
  kw --file kwinrc --group Plugins --key blurEnabled --type bool false
  kw --file kwinrc --group Plugins --key better_blur_dxEnabled --type bool true
  kw "${G[@]}" --key BlurStrength 11
  kw "${G[@]}" --key NoiseStrength 3
  kw "${G[@]}" --key Saturation 170
  kw "${G[@]}" --key Brightness 104
  kw "${G[@]}" --key CornerRadius 12
  kw "${G[@]}" --key BlurDecorations --type bool true
  kw "${G[@]}" --key BlurMenus --type bool true
  kw "${G[@]}" --key BlurDocks --type bool true
  kw "${G[@]}" --key RefractionStrength 6
  kw "${G[@]}" --key RefractionEdgeSize 24
  kw "${G[@]}" --key RefractionCornerRadius 12
  # Only these apps get forced blur, so games are never touched
  kw "${G[@]}" --key WindowClasses "$(printf '%s\n' dolphin org.kde.dolphin konsole org.kde.konsole systemsettings org.kde.systemsettings kate org.kde.kate plasma-systemmonitor ark gwenview)"
  kw "${G[@]}" --key BlurMatching --type bool true
  kw "${G[@]}" --key BlurNonMatching --type bool false
  ok "Better Blur DX with light refraction"
else
  kw --file kwinrc --group Plugins --key blurEnabled --type bool true
  kw --file kwinrc --group Effect-blur --key BlurStrength 12
  kw --file kwinrc --group Effect-blur --key NoiseStrength 4
  ok "Stock KWin blur, turned up"
fi
compgen -G "/usr/lib/qt6/plugins/kwin/effects/plugins/*shapecorners*" >/dev/null && \
  kw --file kwinrc --group Plugins --key kwin4_effect_shapecornersEnabled --type bool true

# GTK apps: same theme, icons, cursor, font and left-side window buttons
for v in 3.0 4.0; do
  G=(--file "$HOME/.config/gtk-$v/settings.ini" --group Settings)
  mkdir -p "$HOME/.config/gtk-$v"
  kw "${G[@]}" --key gtk-theme-name WhiteSur-Dark
  kw "${G[@]}" --key gtk-icon-theme-name WhiteSur-dark
  kw "${G[@]}" --key gtk-cursor-theme-name WhiteSur-cursors
  kw "${G[@]}" --key gtk-font-name "Inter 10"
  kw "${G[@]}" --key gtk-application-prefer-dark-theme true
  kw "${G[@]}" --key gtk-decoration-layout "close,minimize,maximize:"
done
X="$HOME/.config/xsettingsd/xsettingsd.conf"
if [[ -f "$X" ]]; then
  sed -i -E 's|^Net/ThemeName .*|Net/ThemeName "WhiteSur-Dark"|; s|^Net/IconThemeName .*|Net/IconThemeName "WhiteSur-dark"|; s|^Gtk/CursorThemeName .*|Gtk/CursorThemeName "WhiteSur-cursors"|; s|^Gtk/FontName .*|Gtk/FontName "Inter,  10"|; s|^Gtk/DecorationLayout .*|Gtk/DecorationLayout "close,minimize,maximize:"|' "$X"
fi
if have gsettings; then
  gsettings set org.gnome.desktop.interface gtk-theme WhiteSur-Dark 2>/dev/null
  gsettings set org.gnome.desktop.interface icon-theme WhiteSur-dark 2>/dev/null
  gsettings set org.gnome.desktop.interface cursor-theme WhiteSur-cursors 2>/dev/null
  gsettings set org.gnome.desktop.interface font-name "Inter 10" 2>/dev/null
  gsettings set org.gnome.desktop.interface color-scheme prefer-dark 2>/dev/null
  gsettings set org.gnome.desktop.wm.preferences button-layout "close,minimize,maximize:" 2>/dev/null
fi
[[ -n "$QDBUS" ]] && "$QDBUS" org.kde.kded6 /modules/gtkconfig org.kde.GtkConfig.setGtkTheme WhiteSur-Dark >/dev/null 2>&1
ok "GTK apps match (theme, icons, font, buttons on the left)"

# Firefox: use the window title bar, so it gets the same glass buttons as every other app
FP=/etc/firefox/policies/policies.json
if sudo mkdir -p /etc/firefox/policies 2>/dev/null; then
  sudo python3 - "$FP" <<'PY' && ok "Firefox uses the glass title bar" || warn "Firefox title bar not changed"
import json, os, sys
p = sys.argv[1]
d = {}
if os.path.exists(p):
    try: d = json.load(open(p))
    except Exception: d = {}
prefs = d.setdefault("policies", {}).setdefault("Preferences", {})
prefs["browser.tabs.inTitlebar"] = {"Value": 0, "Status": "default"}
json.dump(d, open(p, "w"), indent=2)
PY
fi

# Konsole: glass terminal
mkdir -p "$HOME/.local/share/konsole"
cp "$KIT/files/konsole/Glass.profile" "$KIT/files/konsole/Glass.colorscheme" "$HOME/.local/share/konsole/"
kw --file konsolerc --group "Desktop Entry" --key DefaultProfile Glass.profile
ok "Konsole glass profile"

# Wallpaper + lock screen
mkdir -p "$WALL_DIR/contents/images"
cp "$KIT/files/wallpaper/3840x2160.png" "$WALL_DIR/contents/images/"
cat > "$WALL_DIR/metadata.json" <<'J'
{ "KPlugin": { "Id": "CrazyOS", "Name": "CrazyOS", "Authors": [{ "Name": "CrazyOS" }], "License": "CC-BY-SA-4.0" } }
J
kw --file kscreenlockerrc --group Greeter --group Wallpaper --group org.kde.image --group General --key Image "file://$WALL_DIR/contents/images/3840x2160.png"

# ---------------------------------------------------------------- layout
if [[ $LAYOUT == 1 && -n "$QDBUS" ]]; then
  step "Panel layout: glass top bar + floating dock"
  if ask "Replace your current panels? (backup kept)"; then
    for _ in $(seq 1 30); do "$QDBUS" org.kde.plasmashell >/dev/null 2>&1 && break; sleep 1; done
    "$QDBUS" org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "$(cat "$KIT/files/plasma/layout.js")" >/dev/null \
      && ok "Layout applied" || warn "Layout script failed; panels unchanged"
  else
    ok "Kept your panels"
  fi
fi

# ---------------------------------------------------------------- live session: install entry point
if [[ $LIVE == 1 && -f /usr/share/applications/crazyos-install.desktop ]]; then
  step "Live session: Install CrazyOS"
  DESK="$(xdg-user-dir DESKTOP 2>/dev/null)"; [[ -n "$DESK" ]] || DESK="$HOME/Desktop"
  mkdir -p "$DESK"
  cp /usr/share/applications/crazyos-install.desktop "$DESK/" && chmod +x "$DESK/crazyos-install.desktop"
  have gio && gio set "$DESK/crazyos-install.desktop" metadata::trusted true 2>/dev/null
  DOCKJS='var ps=panels();for(var i=0;i<ps.length;i++){var ws=ps[i].widgets("org.kde.plasma.icontasks");for(var j=0;j<ws.length;j++){var w=ws[j];w.currentConfigGroup=["General"];var l=w.readConfig("launchers","");var a=(typeof l==="string")?(l?l.split(","):[]):l;if(a.indexOf("applications:crazyos-install.desktop")<0){a.unshift("applications:crazyos-install.desktop");w.writeConfig("launchers",a);}}}'
  [[ -n "$QDBUS" ]] && "$QDBUS" org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "$DOCKJS" >/dev/null 2>&1
  ok "Install CrazyOS: icon on the desktop and first in the dock"
  # The CrazyOS installer has its own welcome page, so CachyOS Hello isn't needed in the live session
  pkill -f cachyos-hello >/dev/null 2>&1
  mkdir -p "$HOME/.config/autostart"
  printf '[Desktop Entry]\nHidden=true\n' > "$HOME/.config/autostart/cachyos-hello.desktop"
fi

# ---------------------------------------------------------------- clean top bar
step "Clean top bar: one-click control panel"
if have python3; then
  systemctl --user stop plasma-plasmashell.service >/dev/null 2>&1 || kquitapp6 plasmashell >/dev/null 2>&1
  sleep 2
  python3 "$KIT/files/plasma/tray.py" && ok "Only network and sound in the bar; everything else in one panel" || warn "Tray not changed"
  systemctl --user start plasma-plasmashell.service >/dev/null 2>&1 || (kstart plasmashell >/dev/null 2>&1 &)
  if [[ -n "$QDBUS" ]]; then for _ in $(seq 1 30); do "$QDBUS" org.kde.plasmashell >/dev/null 2>&1 && break; sleep 1; done; sleep 3; fi
fi

# ---------------------------------------------------------------- wallpaper (last, so nothing overrides it)
step "Wallpaper"
IMG="$WALL_DIR/contents/images/3840x2160.png"
WJS="var ds=desktops();for(var i=0;i<ds.length;i++){var d=ds[i];d.wallpaperPlugin='org.kde.image';d.currentConfigGroup=['Wallpaper','org.kde.image','General'];d.writeConfig('Image','file://$IMG');}"
if [[ -n "$QDBUS" ]] && "$QDBUS" org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "$WJS" >/dev/null 2>&1; then
  ok "CrazyOS wallpaper on every screen"
else
  plasma-apply-wallpaperimage "$IMG" >/dev/null 2>&1 && ok "CrazyOS wallpaper" || warn "Set the wallpaper manually from $WALL_DIR"
fi

# ---------------------------------------------------------------- reload
step "Reloading the desktop"
[[ -n "$QDBUS" ]] && "$QDBUS" org.kde.KWin /KWin reconfigure >/dev/null 2>&1
if [[ $LIVE == 0 ]]; then
  systemctl --user restart plasma-plasmashell.service >/dev/null 2>&1 || { kquitapp6 plasmashell >/dev/null 2>&1; (kstart plasmashell >/dev/null 2>&1 &); }
fi
mkdir -p "$STATE"; touch "$STATE/done"
ok "Done"
printf '\n  %sLog out and back in once%s so every app picks up the glass look.\n' "$c_b" "$c_0"
[[ $BBDX == 1 ]] && printf '  After a Plasma update, if the blur disappears run:  %s -S kwin-effects-better-blur-dx\n' "${HELPER:-paru}"
printf '  Undo everything:  %s/glass-restore.sh\n\n' "$KIT"
if [[ $FIRST == 1 && -x "$KIT/turbo-setup.sh" ]]; then
  printf '%s  ⚡ CrazyOS Turbo%s: gaming and low-latency tuning for this PC.\n' "$c_c$c_b" "$c_0"
  if ask "Apply it too?"; then "$KIT/turbo-setup.sh"; else echo "  Skipped. Run 'crazyos-turbo' any time."; fi
fi
[[ $FIRST == 1 ]] && sleep 6
exit 0

# CrazyOS

**Liquid glass. Built for speed.** CrazyOS is a CachyOS-based Linux for gamers. You get a frosted-glass KDE Plasma 6 desktop, plus Turbo tuning for low latency and fast networking.

> CrazyOS is an unofficial community build on top of [CachyOS](https://cachyos.org). It is not affiliated with or endorsed by the CachyOS team. Inside, it is CachyOS: same kernel, packages and updates. "About this System" will still say CachyOS.

**What it uses**
- **WhiteSur Liquid** (dark) — Plasma style, colours, window buttons, Kvantum app style
- **Better Blur DX** — real frosted blur behind windows, with a light "liquid" edge refraction
- **WhiteSur** icons and cursors, **Inter** UI font, **JetBrains Mono Nerd Font** in the terminal
- A custom wallpaper, glass Konsole profile, and a top bar + floating dock layout

---

## Option A — Make your current PC glass (no reinstall)

```bash
unzip crazyos.zip && cd crazyos
./glass-setup.sh
```

It asks before replacing your panels. Then log out and back in once.

| Option | What it does |
|---|---|
| `--yes` | Don't ask, do everything |
| `--no-layout` | Keep your current panels |
| `--no-aur` | Skip Better Blur DX, use the stock KWin blur |
| `--rounded` | Also install the Rounded Corners effect (AUR) |

**Undo:** `./glass-restore.sh` puts your previous KDE settings back. Every file is backed up in `~/.local/share/crazyos/` before anything changes.

## Option B — Build your own ISO

On a CachyOS PC (about 20 GB free, 15–40 minutes):

```bash
./build-iso.sh
```

You get `out/crazyos-YYYYMMDD.iso` and a `.sha256` checksum. Flash it with Ventoy, or with Rufus in DD mode.

- **Live USB:** boots straight into the glass desktop. Click **Install CrazyOS** on the desktop or in the dock: the installer opens right away, with CrazyOS branding and a slideshow.
- **After installing:** on first login, a terminal offers to apply the glass look, then CrazyOS Turbo. This needs internet so it can build Better Blur DX for your system. You can also run `glass-setup` or `turbo-setup` any time later.

It's built from the official CachyOS ISO recipe at build time, so you always get the latest kernel and packages.

### No Linux PC handy? Build it on GitHub from your phone
GitHub builds the ISO for you for free, the same way CachyOS builds its official ISOs.
1. Create a **public** repository on github.com.
2. Upload `crazyos.zip` to it, unchanged.
3. Add a file named `.github/workflows/build.yml` with the contents of `ci/build.yml`.
4. Open **Actions → Build CrazyOS ISO → Run workflow**.
5. After 30–90 minutes, download `crazyos-iso` from the finished run. The download is kept for 7 days.

> If the CachyOS installer changes upstream and the first-login offer doesn't appear, just copy this folder to the new system and run `./glass-setup.sh`.

---

# ⚡ CrazyOS Turbo (gaming & low latency)

Tuned for **Ryzen 7 9800X3D · RTX 5080 · Samsung NVMe · 2.5 GbE**. It only adds what CachyOS doesn't already do. CachyOS already ships its optimised kernel, ntsync, zram, the NVMe I/O scheduler, ananicy-cpp and `game-performance`.

```bash
./turbo-setup.sh --check     # see what's right and wrong, changes nothing
./turbo-setup.sh             # apply
./turbo-setup.sh --scx       # also use the scx_lavd gaming CPU scheduler
./turbo-restore.sh           # remove everything it added
```
Reboot once afterwards.

**What it changes**
| Area | Change |
|---|---|
| Network | BBR + fq, bigger buffers for 2.5 GbE downloads. Energy-Efficient Ethernet off and faster interrupts on the wired port, re-applied on every link-up |
| Input | USB devices never autosuspend, so the first mouse movement or key press is never delayed |
| GPU | Stays fully awake. Page Attribute Table on. 12 GB shader cache that never gets trimmed, so fewer stutters after the first run |
| Kernel | Split-lock throttling off, no memory-compaction stalls mid-game, PCIe power saving off |
| Games | `gamefast` launcher (below), MangoHud, proton-cachyos |
| Fast boot | Boot menu 1 s instead of 5 s, no slow Limine splash image, lz4 boot image, no waiting for the network. Check with `crazyos-turbo --boot-report`; optional `--autologin` |

**In Steam, for each game:** Properties → Compatibility → **proton-cachyos**, then Launch options:
```
gamefast %command%                  # performance CPU mode + newest DLSS
gamefast -l -f 237 %command%        # competitive: low-latency mode + frame cap
gamefast -h %command%               # show the MangoHud overlay
```
- **Frame cap:** set it to your refresh rate minus 3 (141 on 144 Hz, 237 on 240 Hz), so VRR never hits the V-Sync ceiling.
- **Reflex:** in games that have NVIDIA Reflex, set it to **On + Boost**. proton-cachyos supports it.
- **Turning off the DLSS update:** if a game misbehaves after the DLSS swap, add `PROTON_DLSS_UPGRADE=0` before `gamefast`.

## CrazyOS as its own system (packages and updates)

CrazyOS sits on top of CachyOS the way CachyOS sits on top of Arch: the kernel, drivers and apps come from CachyOS, and CrazyOS adds its own **[crazyos]** package repository:

| Package | What's in it |
|---|---|
| `crazyos-branding` | Name (os-release, boot menu title), logo, wallpaper, colour scheme |
| `crazyos-themes` | WhiteSur Liquid theme, icons and cursors, with the CrazyOS logo |
| `crazyos-tools` | `crazyos-glass`, `crazyos-turbo`, CrazyOS Welcome, first-login setup |
| `darkly`, `kwin-effects-better-blur-dx` | Built every week against the current CachyOS Plasma, so the blur keeps working after Plasma updates |

Installed systems get CrazyOS updates with the normal `sudo pacman -Syu`. The system keeps calling itself CrazyOS after CachyOS updates (a pacman hook takes care of that).

**Turn the repository on (one time):**
1. In your GitHub repo, add `ci/repo.yml` as `.github/workflows/repo.yml` (next to `build.yml`), and upload the latest `crazyos.zip`.
2. **Actions → Publish CrazyOS packages → Run workflow.** It takes 10 to 25 minutes, then a release called `repo` appears. That's the package repository, not a download for users.
3. It rebuilds every Monday on its own. Run it by hand after you change the kit.

The address is in `files/repo.conf`. While the repository isn't published, the installer copies CrazyOS from the USB stick instead, so installing always works.

To build the packages on your own PC instead: `bash packaging/build-repo.sh` (output in `packaging/out/`).

**What the installer does now:** no Desktop page (Plasma only), installs the CrazyOS packages, names the system CrazyOS, removes CachyOS Hello's autostart, and sets up the glass look so the very first login is already CrazyOS. The panels, top bar and dock are added a few seconds after that first login.

## CrazyOS Welcome

CrazyOS Welcome replaces CachyOS Hello, both on the USB stick and after installing.

- **On the USB stick** it opens at login with one big **Install CrazyOS** button, plus shortcuts to Wi-Fi and display settings.
- **After installing** it opens at your first login with: Glass look, Turbo, Gaming apps (Steam, Lutris, Heroic), Update, Boot speed and Settings. Untick *Show this when I log in* to stop it appearing.
- Open it any time from the menu: search **Welcome**, or run `crazyos-welcome`.

The USB stick also starts with the CrazyOS look already in place, so there's no plain-CachyOS desktop first, and the computer is named `crazyos`.

## Do these by hand (the biggest wins)
**BIOS** — `--check` tells you if these are off:
- **EXPO** on. DDR5-6000 is the sweet spot for the 9800X3D.
- **Re-Size BAR** + **Above 4G Decoding** on.
- **PBO** Enabled, with Curve Optimizer at −10 to −20 all-core. Test stability with a long game session.
- Leave C-states on. The 9800X3D boosts higher with them.
- **Memory Context Restore** + **Power Down Enable** on (memory settings): on AM5 this often halves the time before the screen even shows the logo.
- Optionally **Fast Boot** on, and unused onboard devices (extra SATA/USB controllers, Wi-Fi) off.

**System Settings (KDE):**
- **Display:** Adaptive Sync **Automatic**, refresh rate at its maximum, and **Allow tearing in fullscreen** on.
- **Mouse:** Acceleration profile **Flat**. Set the polling rate (1000 Hz or more) in the mouse's own software or onboard memory.

**Router:** the 2.5 GbE port can't beat your internet line. For steady ping while others stream or download, turn on **SQM / Smart Queue (cake)** on the router.

## Deliberately not done
- **`mitigations=off`:** tiny gain on Zen 5, and it opens real security holes (your browser runs untrusted code).
- **GPU overclock or forced max clocks:** more heat and noise for 1–3%. Use undervolting tools if you want that.
- **Real-time (RT) kernel:** worse for gaming throughput.

---

## Gaming notes
- **Games are left alone:** forced blur only applies to desktop apps (Dolphin, Konsole, Settings, Kate…), and fullscreen games bypass the compositor.
- **After a big Plasma update the blur may vanish.** The effect is compiled for one KWin version, so rebuild it:
  `paru -S kwin-effects-better-blur-dx`, then log out and back in.
- **Stutter or high cursor latency on Wayland:** turn the blur strength down, or switch back with `./glass-setup.sh --no-aur`.

## Tweaking
- **Blur and refraction strength:** System Settings → Desktop Effects → Better Blur DX
- **Window transparency:** Kvantum Manager → Configure → WhiteSurLiquidDark
- **Terminal transparency:** Konsole → Settings → Edit profile → Appearance → Glass

## Sharing the ISO
- **Where to host it:** the ISO is about 3.2 GB. That's too big for Netlify, which isn't built for files over 10 MB, and for a single GitHub release file (2 GiB limit). Upload it to **SourceForge** with `rsync` (its web form only takes files under about 477 MB), or split it into parts for GitHub Releases.
- **Licences:** almost everything inside is GPL software. Keep these build scripts public (for example on GitHub) and link to CachyOS's and Arch's source repositories from your download page.

## Credits
- WhiteSur KDE, icons and cursors by vinceliuice (GPL-3.0)
- Better Blur DX by xarblu and contributors (GPL-3.0)
- CachyOS Live ISO recipe by the CachyOS team (GPL-3.0)

These are downloaded from their own repositories when you run the scripts; nothing of theirs is modified.

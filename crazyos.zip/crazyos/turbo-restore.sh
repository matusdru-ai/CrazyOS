#!/usr/bin/env bash
# Removes everything turbo-setup.sh added, then asks you to reboot.
set -uo pipefail
R="${TURBO_ROOT:-}"
M="$R/etc/crazyos-turbo.manifest"
[[ -f "$M" ]] || { echo "Nothing to undo (no $M)."; exit 0; }

[[ -z "$R" ]] && sudo systemctl disable --now crazyos-turbo-nic.service >/dev/null 2>&1
GRUB=0
while read -r f; do
  case "$f" in
    "") ;;
    MOD:*)  p="${f#MOD:}"
            if [[ -f "$R$p.crazyos-bak" ]]; then sudo mv "$R$p.crazyos-bak" "$R$p" && echo "  restored $p"; fi
            [[ "$p" == /etc/default/grub ]] && GRUB=1 ;;
    SVC:*)  [[ -z "$R" ]] && sudo systemctl enable "${f#SVC:}" >/dev/null 2>&1 && echo "  re-enabled ${f#SVC:}" ;;
    /etc/scx_loader.toml) ;;
    *)      sudo rm -f "$R$f" && echo "  removed $f" ;;
  esac
done < "$M"
[[ $GRUB == 1 && -z "$R" ]] && sudo grub-mkconfig -o /boot/grub/grub.cfg >/dev/null 2>&1
if grep -qx /etc/scx_loader.toml "$M"; then
  if [[ -f "$R/etc/scx_loader.toml.turbo-backup" ]]; then sudo mv "$R/etc/scx_loader.toml.turbo-backup" "$R/etc/scx_loader.toml"; echo "  restored /etc/scx_loader.toml"
  else sudo rm -f "$R/etc/scx_loader.toml"; [[ -z "$R" ]] && sudo systemctl disable --now scx_loader.service >/dev/null 2>&1; echo "  removed /etc/scx_loader.toml"; fi
fi
sudo rmdir "$R/usr/local/lib/crazyos-turbo" 2>/dev/null
sudo rm -f "$M"
if [[ -z "$R" ]]; then
  sudo systemctl daemon-reload; sudo udevadm control --reload
  sudo mkinitcpio -P >/dev/null 2>&1
fi
echo
echo "Done. Reboot to return fully to CachyOS defaults."

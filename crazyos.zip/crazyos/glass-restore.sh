#!/usr/bin/env bash
# Puts back the KDE settings saved by glass-setup.sh (the most recent backup, or the one you pass).
#   ./glass-restore.sh                     latest backup
#   ./glass-restore.sh <backup-folder>     a specific one
set -uo pipefail
STATE="$HOME/.local/share/crazyos"
BK="${1:-$(ls -1d "$STATE"/backup-* 2>/dev/null | sort | tail -n1)}"
[[ -n "$BK" && -d "$BK" ]] || { echo "No backup found in $STATE"; exit 1; }

echo "Restoring settings from $BK"
(cd "$BK" && find . -type f) | while read -r f; do
  mkdir -p "$HOME/.config/$(dirname "$f")"
  cp -a "$BK/$f" "$HOME/.config/$f" && echo "  ✓ ${f#./}"
done
# Files glass-setup created that didn't exist before
[[ -f "$BK/Kvantum/kvantum.kvconfig" ]] || rm -f "$HOME/.config/Kvantum/kvantum.kvconfig"
rm -f "$STATE/done"

for q in qdbus6 qdbus-qt6 /usr/lib/qt6/bin/qdbus qdbus; do command -v "$q" >/dev/null && { "$q" org.kde.KWin /KWin reconfigure >/dev/null 2>&1; break; }; done
systemctl --user restart plasma-plasmashell.service >/dev/null 2>&1 || { kquitapp6 plasmashell >/dev/null 2>&1; (kstart plasmashell >/dev/null 2>&1 &); }
echo
echo "Done. Log out and back in to finish. Installed themes and packages were left in place;"
echo "remove them with:  paru -Rns kwin-effects-better-blur-dx   (optional)"

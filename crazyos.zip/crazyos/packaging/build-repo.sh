#!/bin/bash
# Builds every CrazyOS package and the [crazyos] pacman repository.
# Runs inside an Arch Linux container (GitHub Actions) or on any CachyOS/Arch PC:
#   sudo bash packaging/build-repo.sh            -> packaging/out/
set -euo pipefail
KIT="$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)"
OUT="$KIT/packaging/out"; WORK="$KIT/packaging/work"
AUR=(darkly kwin-effects-better-blur-dx)

if [[ $EUID -eq 0 && -f /.dockerenv ]] || [[ "${GITHUB_ACTIONS:-}" == true && $EUID -eq 0 ]]; then
  # fresh container: same CachyOS packages users get, so the blur plugin matches their KWin
  pacman-key --init
  pacman-key --recv-keys F3B607488DB35A47 --keyserver keyserver.ubuntu.com
  pacman-key --lsign-key F3B607488DB35A47
  grep -q '^\[cachyos\]' /etc/pacman.conf || \
    sed -i '/^\[core\]$/i[cachyos]\nServer = https://mirror.cachyos.org/repo/$arch/$repo\n' /etc/pacman.conf
  pacman -Syu --noconfirm --needed base-devel git curl sudo cachyos-keyring
  id builder >/dev/null 2>&1 || useradd -m builder
  echo "builder ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/builder
  chown -R builder: "$KIT"
  exec sudo -H -u builder env GITHUB_ACTIONS="${GITHUB_ACTIONS:-}" bash "$0"
fi
[[ $EUID -ne 0 ]] || { echo "Run as your normal user (makepkg refuses root)"; exit 1; }

rm -rf "$OUT" "$WORK"; mkdir -p "$OUT" "$WORK"

echo "== CrazyOS packages"
cp -r "$KIT/packaging/crazyos" "$WORK/crazyos"
sed -i "s/^pkgver=.*/pkgver=$(date -u +%Y.%m.%d.%H%M)/" "$WORK/crazyos/PKGBUILD"
(cd "$WORK/crazyos" && CRAZYOS_KIT="$KIT" makepkg -sf --noconfirm)
cp "$WORK"/crazyos/*.pkg.tar.zst "$OUT/"

for p in "${AUR[@]}"; do
  echo "== $p (from the AUR, built against current CachyOS Plasma)"
  git clone -q --depth 1 "https://aur.archlinux.org/$p.git" "$WORK/$p"
  if (cd "$WORK/$p" && makepkg -sf --noconfirm); then
    find "$WORK/$p" -maxdepth 1 -name '*.pkg.tar.zst' ! -name '*-debug-*' -exec cp {} "$OUT/" \;
  else
    echo "!! $p failed to build; keeping the previously published version"
    find "$KIT/packaging/prev" -maxdepth 1 -name "$p-[0-9]*.pkg.tar.zst" -exec cp {} "$OUT/" \; 2>/dev/null || true
  fi
done

echo "== Repository"
cd "$OUT"
repo-add -q crazyos.db.tar.gz ./*.pkg.tar.zst
# GitHub release assets can't be symlinks
for f in crazyos.db crazyos.files; do rm -f "$f"; cp "$f.tar.gz" "$f"; done
ls -la "$OUT"

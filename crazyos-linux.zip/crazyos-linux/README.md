# CrazyOS 26.10 "No Label": real Linux

A real Linux distribution by **Crazyaimone**, built on **Debian 13** with the **KDE Plasma** desktop.
Boot it from a USB stick or in a virtual machine, then install it on a PC if you like it.
Everything normal Linux does works here: `apt install`, Flatpak, Steam with Proton, drivers, servers, coding.

## What's inside

| | |
|---|---|
| **Desktop** | KDE Plasma, dark CrazyOS theme with crimson accent, CrazyOS wallpaper and login screen |
| **Music production** | Ardour (pro DAW), LMMS, Audacity, Hydrogen drums, Carla. Plugins: x42 (includes **x42-autotune**), Calf, LSP, ZAM, Dragonfly reverb. Low-latency PipeWire + JACK, real-time audio priority for the live user |
| **Your music** | `~/Music/Crazyaimone/`: Still Alive instrumental + previews, ready to record over |
| **Gaming** | Steam with **Proton** (one click in CrazyOS Welcome, from Flathub), Lutris, GameMode, MangoHud, Vulkan drivers |
| **Apps** | Firefox, Discover app store with Flathub (Spotify, Discord, …), VLC, GIMP, Krita, Inkscape, OBS Studio, Kdenlive |
| **Dev** | Python 3 + pip, Node.js + npm, git, build tools, vim/nano, fastfetch with the CrazyOS logo |
| **Installer** | "Install CrazyOS" (Calamares) puts it on a hard drive, branded CrazyOS |

Live session user: **crazy**, no password needed. `sudo` works.

---

## 1 · Build the ISO for free on GitHub (no Linux needed)

1. Make a free account at **github.com**, then **New repository** → name it `crazyos-linux` → **Public** (public repos get unlimited free build minutes) → **Create**.
2. On the new repo page click **uploading an existing file**. Unzip `crazyos-linux.zip` on your computer, open the `crazyos-linux` folder, select **everything inside it** and drag it into the page. Press **Commit changes**.
3. Check that the file `.github/workflows/build-iso.yml` is in the repo. Some browsers skip folders that start with a dot.
   If it's missing, use **Add file → Create new file**, type `.github/workflows/build-iso.yml` as the name, paste the contents of that file from the zip, then **Commit**.
4. Open the **Actions** tab. If asked, press **I understand my workflows, go ahead and enable them**. Click **Build CrazyOS ISO** → **Run workflow**.
5. Wait about 45–90 minutes. When the run turns green, open it and download **CrazyOS-26.10-amd64** under *Artifacts*. It's a zip with the `.iso` inside.

If the run turns red, download the **build-log** artifact and send it over: it says exactly what to fix.

## 2 · Put it on a USB stick

- **Easiest:** [balenaEtcher](https://etcher.balena.io/) → *Flash from file* → pick `CrazyOS-26.10-amd64.iso` → pick the USB (8 GB or bigger, it gets erased) → *Flash*.
- **Windows alternative:** Rufus → select the ISO → when asked, choose **DD image mode**.
- **Several ISOs on one stick:** Ventoy, then copy the ISO onto the stick.

Boot the PC from the USB (boot menu key is usually F12, F11, F8 or Esc). If it won't start, turn off **Secure Boot** in the BIOS/UEFI settings.

## 3 · Or run it in a virtual machine

- **VirtualBox** (Windows/Mac Intel/Linux): New → Type *Linux*, Version *Debian (64-bit)* → 4 GB RAM or more, 2+ CPUs → 40 GB disk → Settings → Storage → put the ISO in the optical drive → Display: 128 MB video memory → Start.
- **VMware Workstation Player**: Create a new VM → installer disc image → the ISO → Debian 12.x 64-bit.
- **GNOME Boxes / virt-manager** on Linux: open the ISO.
- Apple Silicon Macs (M1–M4) can't run this x86-64 image at usable speed.

## 4 · Install it for real

Inside the live system, open **CrazyOS Welcome** → **Install CrazyOS on this computer**, or press "Install CrazyOS" in the menu. You can erase the disk or install next to Windows (dual boot). Back up first.

## Build on your own Linux machine instead

```bash
# Debian 13 / Ubuntu 24.04+ with Docker:
docker run --rm --privileged -v "$PWD":/build -w /build debian:trixie \
  bash -c "apt-get update && apt-get install -y live-build && bash build.sh"
# or natively on Debian 13:
sudo apt install live-build && sudo ./build.sh
```
The ISO lands in `out/`.

## Change things

- Apps: `config/package-lists/crazyos.list.chroot` (must exist) and the `EXTRAS` line in `config/hooks/normal/0100-crazyos-packages.hook.chroot` (skipped if missing).
- Branding, prompt, installer: `config/hooks/normal/0200-crazyos-branding.hook.chroot`.
- Wallpaper: `config/includes.chroot/usr/share/wallpapers/CrazyOS/`.
- Welcome app: `config/includes.chroot/usr/local/bin/crazyos-welcome`.

Push a change and GitHub builds a new ISO automatically.

---
CrazyOS is built from Debian's free software and keeps its licenses. Music, artwork and the CrazyOS name © Crazyaimone.

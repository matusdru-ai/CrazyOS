[Appearance]
ColorScheme=CrazyOS

[General]
Name=CrazyOS
Parent=FALLBACK/
TerminalColumns=110
TerminalRows=30

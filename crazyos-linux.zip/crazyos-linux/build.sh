#!/bin/bash
# Build the CrazyOS ISO. Run as root on Debian 13 (trixie) or newer with live-build installed:
#   sudo apt install live-build && sudo ./build.sh
# Or anywhere with Docker:
#   docker run --rm --privileged -v "$PWD":/build -w /build debian:trixie bash -c "apt-get update && apt-get install -y live-build && bash build.sh"
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" = 0 ] || { echo "run as root (sudo ./build.sh)"; exit 1; }
chmod +x auto/* config/hooks/normal/*.hook.chroot config/includes.chroot/usr/local/bin/* 2>/dev/null || true
lb clean --purge >/dev/null 2>&1 || true
lb config
lb build
mkdir -p out
ISO=$(ls -1 *.iso | head -n1)
mv "$ISO" out/CrazyOS-26.10-amd64.iso
( cd out && sha256sum CrazyOS-26.10-amd64.iso > SHA256SUMS )
ls -lh out
echo "done: out/CrazyOS-26.10-amd64.iso"
